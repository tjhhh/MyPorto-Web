# PRODUCT REQUIREMENTS DOCUMENT (PRD)
## Project Etihad: 3D Cartoon Tactical Diorama Portfolio

* **Versi Dokumen:** 1.0
* **Tanggal:** Oktober 2026
* **Product Owner:** [Nama Anda / Jersey #17]
* **Tech Stack Utama:** Next.js (App Router), TypeScript, React Three Fiber (R3F), Three.js, Zustand, Tailwind CSS, Supabase Realtime, Blender 3D.

---

## 1. Executive Summary & Visi Produk

### 1.1 Latar Belakang Masalah
Web portofolio berbasis 3D sering kali terjebak dalam dua masalah ekstrem:
1. **Terlalu Generik:** Hanya menampilkan objek 3D berputar di halaman *landing* tanpa fungsi nyata.
2. **Terlalu Rumit (*Over-engineered Open World*):** Memaksa pengunjung (terutama HRD/Recruiter yang hanya punya waktu 30–60 detik) untuk berjalan jauh di lorong virtual dengan kontrol yang membingungkan, sehingga berujung pada *bounce rate* tinggi.

### 1.2 Solusi Radikal: "The Etihad Cutaway Diorama"
Membangun web portofolio interaktif bertekstur kartun (*cel-shaded / baked stylized*) yang mengadaptasi ekosistem **Etihad Stadium** dalam bentuk **Isometric Cutaway Diorama** (stadion yang dibelah melintang seperti maket taktikal). 

Pengunjung dapat menggerakkan karakter utama (menggunakan kontrol jalan maupun tendangan bola jarak jauh) untuk menjelajahi 4 zona inti: **Dressing Room (Skills)**, **Trophy & VAR Room (Projects)**, **Glass Tunnel (Experience)**, dan **The Pitch (Contact/CTA)**—atau beralih secara instan ke **Tactical 2D Board Mode** hanya dengan 1 klik.

### 1.3 Target Metrik Kesuksesan (KPI)
* **Initial Load Time (LCP):** `< 2.5 detik` pada koneksi 4G/Wi-Fi standar.
* **Ukuran Total Aset 3D:** `< 4.5 MB` (setelah kompresi Draco & WebP/KTX2).
* **Performa Render:** Stabil di `60 FPS` pada laptop standar dan smartphone kelas menengah.
* **Waktu Akses Informasi Utama:** `< 5 detik` untuk membuka detail proyek atau mengunduh CV (melalui Minimap atau 2D Switch).

---

## 2. Target Audiens & User Personas

| Persona | Ekspektasi & Batasan Waktu | Solusi Fitur di Dalam Produk |
| :--- | :--- | :--- |
| **1. Tech Recruiter / HRD** | Punya waktu `< 45 detik`. Tidak ingin bermain game; butuh daftar skill, proyek, dan tombol Download CV secepat mungkin. | **Tactical Board Mode (2D Switch):** Tombol mencolok di header yang mengubah tampilan 3D menjadi papan taktik 2D super rapi dan cepat. |
| **2. Engineering Manager / CTO** | Punya waktu `2–5 menit`. Ingin melihat kualitas arsitektur kode, penyelesaian masalah teknis, dan performa aplikasi. | **VAR Control Room** (menampilkan arsitektur sistem & repo) serta **Live Telemetry Scoreboard** (menampilkan FPS, latency, dan realtime visitor). |
| **3. Klien & Sesama Developer** | Eksploratif. Mencari pengalaman berkesan, keunikan *personal branding*, dan detail interaktif. | Eksplorasi karakter 3D penuh, mekanik tendangan melengkung (**Curve Pass Trigger**), kartu **FUT PlayStyles+**, dan efek cuaca dinamis. |

---

## 3. Arsitektur Spasial & Pemetaan 4 Zona Etihad

Diorama dibagi menjadi 4 ruangan bersebelahan dalam satu *scene* utuh (tanpa *loading screen* tambahan saat berpindah ruangan):

```text
+--------------------+     +--------------------+     +--------------------+     +--------------------+
|      ZONA 01       |     |      ZONA 02       |     |      ZONA 03       |     |      ZONA 04       |
|  THE DRESSING ROOM | --> | TROPHY & VAR ROOM  | --> |  THE GLASS TUNNEL  | --> |     THE PITCH      |
|  (Skills & Stack)  |     | (Showcase Project) |     | (Journey & Career) |     |  (Kick-Off & CTA)  |
+--------------------+     +--------------------+     +--------------------+     +--------------------+
```

### 3.1 Zona 01: The Dressing Room (Identity & Tech Stack)
* **Konsep Visual:** Ruang ganti melingkar ikonik Etihad Stadium dengan bangku kayu hangat dan pencahayaan neon *Sky Blue* di setiap loker pemain.
* **Interaksi Utama:** Setiap loker mewakili satu domain keahlian. Saat karakter mendekat atau pengguna mengklik loker, jersey di dalamnya melayang keluar dan membuka **Kartu Statistik ala EA FC (PlayStyles+)**.
* **Pemetaan Konten Skill:**
  * **Loker #1 — PlayStyle+ "Tiki-Taka" (Frontend & Mobile):** Flutter, Next.js, React, TypeScript, Tailwind CSS.
  * **Loker #2 — PlayStyle+ "Engine" (Backend & Cloud):** NestJS, Node.js, Supabase, PostgreSQL, REST/GraphQL.
  * **Loker #3 — PlayStyle+ "Visionary" (IoT, Data & QA):** Mikrokontroler/Telemetry IoT, Automated Testing, Algoritma & Struktur Data.

### 3.2 Zona 02: The Trophy & VAR Room (Project Showcase)
* **Konsep Visual:** Perpaduan ruang pamer trofi kaca dengan deretan layar monitor ruang kontrol *Video Assistant Referee (VAR)*.
* **Interaksi Utama:** Proyek-proyek terbaik dipajang sebagai trofi 3D berdesain khusus di atas pedestal. Ketika trofi dipilih (atau dikenai tendangan bola), layar besar **VAR Review** menyala.
* **Struktur Data VAR Review (Modal/Overlay):**
  * **Match Highlights:** Video singkat / GIF / *Interactive Preview* dari proyek (misal: *ProFutsal*, *HikePass*, *RideAssist*, *Smart Kandang IoT*, *SentraTest*).
  * **Tactical Breakdown:** Diagram arsitektur sistem (bagaimana frontend, backend, atau sensor IoT saling berkomunikasi).
  * **Match Stats:** Tech stack yang digunakan, peran dalam proyek, serta tombol menuju **Live Demo** dan **GitHub Repository**.

### 3.3 Zona 03: The Glass Tunnel (Experience, Research & Education)
* **Konsep Visual:** Terowongan kaca Etihad yang menghubungkan ruang dalam dengan lapangan utama.
* **Interaksi Utama:** Saat karakter berjalan menyusuri lorong, panel kaca di sisi kiri dan kanan memancarkan **Hologram Timeline** secara berurutan:
  * Pengalaman kerja & *internship* (termasuk pengembangan sistem berbasis IoT).
  * Pengalaman mengajar sebagai Asisten Praktikum.
  * Riset akademik dan eksperimen algoritma/visualisasi data.
* **Sentuhan Audio:** Suara gemuruh penonton (*stadium ambiance*) meningkat secara bertahap seiring karakter mendekati ujung lorong.

### 3.4 Zona 04: The Pitch & Jumbotron (Call to Action & Live Telemetry)
* **Konsep Visual:** Area titik tengah lapangan hijau (*Center Circle*) yang menghadap langsung ke layar Jumbotron raksasa di tribun stadion.
* **Interaksi Utama ("Kick-Off Collaboration"):**
  * Di titik tengah terdapat bola utama bertuliskan **"Kick-Off Project"**.
  * Saat diklik, karakter melakukan animasi *long pass* melengkung ke arah layar Jumbotron.
  * Layar Jumbotron bergetar dengan efek visual **"GOAL / FULL-TIME COLLABORATION"** dan memunculkan form kontak cepat, link LinkedIn, GitHub, serta tombol **Download CV (PDF)**.
* **Fitur Ekstra — Live Telemetry Scoreboard:**
  * Papan skor digital di atas Jumbotron menampilkan data aktual: `FPS Counter`, `Jumlah Pengunjung Aktif di Stadion Saat Ini` (via Supabase Realtime Presence), dan `Cuaca Lokal Aktual`.

---

## 4. Mekanik Navigasi & UX Radikal

Agar pengalaman pengguna terasa seperti game kelas atas namun tetap secepat web modern, diterapkan 4 mekanik berikut:

1. **The "Curve Pass" Remote Trigger (Interaksi Tanpa Jalan Kaki):**
   Karakter selalu membawa bola di kakinya. Jika pengguna mengklik trofi proyek atau loker dari jarak jauh, karakter tidak perlu berjalan kaki ke sana—ia langsung menendang bola dengan lintasan melengkung (*Bezier curve*) mengenai objek tersebut dan langsung membuka modal informasinya dalam waktu `< 0.6 detik`.
2. **Pep’s Tactical Board Mode (Instant 2D Switch):**
   Terdapat tombol permanen di *top-bar*: `[ Switch to Tactical 2D View ]`. Ketika diaktifkan, kamera melakukan transisi *zoom-out* tegak lurus ke atas, lalu beralih ke tampilan UI 2D bersih bergaya papan strategi sepak bola. Semua proyek, skill, dan CV dapat diakses secara instan tanpa beban render 3D.
3. **Interactive Radar Minimap:**
   Di pojok kiri bawah terdapat radar 2D ala game sepak bola. Pengguna bisa mengklik nama ruangan di radar untuk langsung memindahkan kamera dan karakter (*instant through-pass*) ke ruangan tersebut.
4. **Hybrid Input Controls:**
   * **Desktop:** `WASD` / `Arrow Keys` untuk jalan manual, atau `Left Click` pada lantai/objek untuk *point-and-click*.
   * **Mobile / Tablet:** *Virtual Joystick* di jempol kiri atau cukup *Tap* langsung pada objek/ruangan.

---

## 5. Spesifikasi Teknis & Pipeline Optimasi

### 5.1 Arsitektur Aplikasi (Next.js + R3F)
```text
src/
├── app/                      # Next.js App Router (SEO Metadata & Layout)
├── components/
│   ├── canvas/               # Komponen 3D (React Three Fiber)
│   │   ├── EtihadDiorama.tsx # Model utama stadion (.glb hasil kompresi)
│   │   ├── PlayerController.tsx # Karakter #17 + NavMesh boundary + Curve Pass
│   │   ├── InteractiveZones/ # Trigger area Dressing Room, VAR, Tunnel, Pitch
│   │   └── CameraRig.tsx     # Isometric smooth camera following & zoom
│   ├── tactical-2d/          # Komponen UI 2D penuh untuk Mode Recruiter
│   └── hud/                  # Overlay UI: Radar Minimap, VAR Modal, FUT Cards, Topbar
├── store/
│   └── useStadiumStore.ts    # Zustand state (activeZone, is2DMode, selectedProject)
└── lib/
    └── telemetry.ts          # Supabase Realtime presence & weather fetcher
```

### 5.2 Aturan Ketat Optimasi 3D (Wajib Dipatuhi)
1. **Dilarang Menggunakan Dynamic Shadows Berat:** Gunakan **Texture Baking** di Blender. Seluruh pencahayaan, gradasi warna kartun, dan *Ambient Occlusion* harus di-*bake* ke dalam maksimal 2 *Texture Atlas* beresolusi 2048x2048 dalam format `.webp` atau `.ktx2`.
2. **Material Ringan:** Gunakan `MeshBasicMaterial` untuk seluruh bangunan stadion yang sudah di-*bake*, dan gunakan `MeshToonMaterial` dengan *1D Gradient Map* hanya untuk karakter pemain dan bola yang bergerak.
3. **Batas Poligon (Polycount Budget):**
   * Seluruh Diorama Stadion: Maksimal `30.000 Triangles`.
   * Karakter Utama + Bola: Maksimal `4.000 Triangles`.
4. **Kompresi Pipeline:** Gunakan `gltf-transform` dengan kompresi **Draco / Meshopt** sehingga ukuran file `.glb` akhir berada di kisaran `2 MB – 4 MB`.
5. **Collision Tanpa Physics Engine Berat:** Jangan gunakan library fisika berat (seperti Rapier/Cannon) hanya untuk berjalan di lantai datar. Gunakan **NavMesh clamping** (`three-mesh-bvh`) untuk membatasi area jalan karakter dan matematika kurva *Quadratic Bezier* di `useFrame` untuk lintasan tendangan bola.

---

## 6. Mitigasi Risiko & Fallback System

* **Risiko 1: Perangkat Pengunjung Tidak Kuat Merender WebGL (Layar Patah-Patah)**
  * *Mitigasi:* Integrasikan `<PerformanceMonitor />` dari `@react-three/drei`. Jika *frame rate* turun di bawah 28 FPS secara konsisten, otomatis matikan *post-processing* dan tawarkan peralihan otomatis ke **Tactical 2D Mode**.
* **Risiko 2: SEO Tidak Terbaca karena Konten Berada di Dalam Canvas 3D**
  * *Mitigasi:* Seluruh teks profil, daftar skill, dan deskripsi proyek dirender sebagai elemen HTML semantik di dalam komponen **Tactical 2D Mode** yang selalu ada di dalam struktur DOM, sehingga *crawler* mesin pencari dapat mengindeks seluruh isi portofolio dengan sempurna.
* **Risiko 3: Kebingungan Pengguna Saat Pertama Kali Masuk**
  * *Mitigasi:* Tampilkan *onboarding tooltip* singkat selama 3 detik di awal: *"Klik ruangan mana saja untuk mengoper bola, gunakan WASD untuk berjalan, atau klik [Tactical 2D] di atas untuk tampilan ringkas."*

---

## 7. Rencana Eksekusi (4-Week Sprint Roadmap)

* **Minggu 1 — Core Mechanics & Greyboxing:**
  * Setup Next.js, R3F, dan Zustand store.
  * Buat model *greybox* (kotak-kotak kasar) 4 ruangan Etihad di Blender untuk menguji proporsi kamera *isometric*.
  * Implementasi pergerakan karakter, kamera *smooth panning*, dan lintasan tendangan bola (*Curve Pass*).
* **Minggu 2 — Tactical 2D Mode & HUD Overlay:**
  * Bangun **Tactical 2D View** sampai tuntas (agar portofolio sudah fungsional 100% secara informasi).
  * Buat komponen UI **Kartu FUT PlayStyles+**, **Layar Modal VAR**, dan **Radar Minimap**.
* **Minggu 3 — 3D Modeling, Cartoon Styling & Texture Baking:**
  * Modeling detail loker ruang ganti, trofi proyek unik, lorong kaca, dan lapangan Etihad di Blender.
  * Proses *UV Unwrapping* dan *Texture Baking* pencahayaan kartun, lalu kompresi ke `.glb`.
* **Minggu 4 — Telemetry, Audio & Final QA:**
  * Integrasi Supabase Realtime untuk menghitung pengunjung aktif di papan skor Jumbotron.
  * Tambahkan efek suara (tendangan bola, peluit kick-off, gemuruh suporter dengan tombol *Mute*).
  * Uji coba lintas perangkat (Desktop, Android, iOS) dan *deployment* ke Vercel.