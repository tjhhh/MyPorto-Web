"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  useStadiumStore,
  STADIUM_LOCKERS,
  STADIUM_TROPHIES,
  STADIUM_MILESTONES,
} from "@/store/useStadiumStore";
import {
  Box,
  FileDown,
  ExternalLink,
  GitBranch,
  ChevronRight,
  Zap,
  Sparkles,
  Trophy,
  Briefcase,
  GraduationCap,
  Mail,
  CheckCircle2,
} from "lucide-react";
import { GithubIcon, LinkedinIcon } from "@/components/ui/BrandIcons";

function getMilestoneIcon(type: string) {
  if (type.includes("Internship")) {
    return <Briefcase className="w-4 h-4" />;
  }
  if (type.includes("Teaching")) {
    return <Trophy className="w-4 h-4" />;
  }
  return <GraduationCap className="w-4 h-4" />;
}

export function TacticalBoardView() {
  const viewMode = useStadiumStore((s) => s.viewMode);
  const toggleViewMode = useStadiumStore((s) => s.toggleViewMode);

  const [activeTab, setActiveTab] = useState<"all" | "skills" | "projects" | "career" | "contact">("all");

  return (
    <div
      className={`transition-all duration-300 ${
        viewMode === "tactical-2d"
          ? "opacity-100 pointer-events-auto"
          : "opacity-0 pointer-events-none absolute inset-0 -z-50 overflow-hidden h-0"
      }`}
    >
      <div className="min-h-screen bg-[#070c14] text-white pt-20 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto space-y-10">
          {/* Tactical Board Top Hero Card */}
          <section
            aria-labelledby="tactical-board-title"
            className="relative bg-gradient-to-r from-[#00285e]/80 via-[#0a1526]/90 to-[#070c14] border-2 border-[#6cabdd]/40 rounded-2xl p-6 sm:p-8 shadow-2xl overflow-hidden"
          >
            {/* Tactical Grid Background Overlay */}
            <div className="absolute inset-0 bg-[radial-gradient(#6cabdd_1px,transparent_1px)] [background-size:24px_24px] opacity-15 pointer-events-none" />

            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#00e5ff]/15 border border-[#00e5ff]/30 rounded-full text-xs font-mono text-[#00e5ff] font-bold">
                  <div className="w-2 h-2 rounded-full bg-[#00e5ff] animate-pulse" />
                  <span>PEP’S TACTICAL BOARD // RECRUITER 2D SPRINT</span>
                </div>

                <h1 id="tactical-board-title" className="text-3xl sm:text-5xl font-black tracking-tight text-white">
                  Muhammad Fauzan <span className="text-[#6cabdd]">#17</span>
                </h1>

                <p className="font-mono text-sm sm:text-base text-[#98c5e9] max-w-2xl leading-relaxed">
                  Full-stack Software Engineer & IoT Telemetry Architect. Mengkhususkan diri pada rekayasa sistem terdistribusi, pipeline data edge ESP32 berlatensi rendah, serta arsitektur mobile Flutter & web Next.js berkinerja 60 FPS.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap sm:flex-col gap-2.5 shrink-0">
                <button
                  onClick={toggleViewMode}
                  className="flex items-center justify-center gap-2 px-5 py-3 bg-[#00e5ff] hover:bg-[#6cabdd] text-[#070c14] font-mono text-xs font-black tracking-wider rounded-xl transition-all shadow-lg shadow-[#00e5ff]/20"
                >
                  <Box className="w-4 h-4" />
                  <span>KEMBALI KE 3D DIORAMA</span>
                </button>

                <a
                  href="/resume.pdf"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 px-5 py-3 bg-[#111e30] hover:bg-[#192b45] text-white font-mono text-xs font-bold rounded-xl border border-white/20 transition-all shadow-md"
                >
                  <FileDown className="w-4 h-4 text-[#ffd700]" />
                  <span>DOWNLOAD CV RESMI (PDF)</span>
                </a>
              </div>
            </div>

            {/* Tactical Navigation Filter Pill Bar */}
            <div className="relative z-10 flex flex-wrap gap-2 pt-6 mt-6 border-t border-white/10">
              {[
                { id: "all", label: "SEMUA TAKTIK (ALL)" },
                { id: "skills", label: "01 // FORMASI SKILL (FUT CARDS)" },
                { id: "projects", label: "02 // ARSIP TROFI PROYEK (VAR)" },
                { id: "career", label: "03 // TIMELINE PENGALAMAN" },
                { id: "contact", label: "04 // KICK-OFF & KONTAK" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as typeof activeTab)}
                  className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition-all ${
                    activeTab === tab.id
                      ? "bg-[#6cabdd] text-black shadow-md"
                      : "bg-[#091220] text-white/70 hover:text-white border border-white/10"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </section>

          {/* ============================================================ */}
          {/* SECTION 1: FORMASI SKILL (ZONA 1 - DRESSING ROOM) */}
          {/* ============================================================ */}
          {(activeTab === "all" || activeTab === "skills") && (
            <section aria-labelledby="skills-section-heading" className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-mono text-xs text-[#00e5ff] font-bold tracking-wider">
                    ZONE 01 // THE DRESSING ROOM
                  </span>
                  <h2 id="skills-section-heading" className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                    EA FC Tactical PlayStyles+ & Keahlian Inti
                  </h2>
                </div>
                <span className="font-mono text-xs text-white/50 hidden sm:inline">
                  3 SPECIALIST PROFILES
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {STADIUM_LOCKERS.map((locker) => (
                  <article
                    key={locker.id}
                    className="relative bg-gradient-to-b from-[#0f1b2c] via-[#09121e] to-[#060a12] border-2 rounded-2xl p-5 shadow-2xl flex flex-col justify-between overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl"
                    style={{
                      borderColor: `${locker.color}75`,
                      boxShadow: `0 8px 32px ${locker.color}20`,
                    }}
                  >
                    <div>
                      {/* Card Header */}
                      <div className="flex items-start justify-between pb-3 border-b border-white/10 mb-3">
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono text-3xl font-black text-[#ffd700]">
                            {locker.overallRating}
                          </span>
                          <div>
                            <span className="font-mono text-xs font-bold text-white block">
                              {locker.position} • 🇮🇩
                            </span>
                            <span className="font-mono text-[10px] text-[#00e5ff] font-bold">
                              {locker.playstyle}
                            </span>
                          </div>
                        </div>

                        <span className="font-mono text-sm font-black text-[#6cabdd] bg-[#00285e] px-2 py-0.5 rounded">
                          #{locker.number}
                        </span>
                      </div>

                      <h3 className="text-lg font-bold text-white mb-1">
                        {locker.category}
                      </h3>
                      <p className="text-xs text-white/70 mb-3 leading-relaxed">
                        {locker.description}
                      </p>

                      {/* 6 Stats Mini Grid */}
                      <div className="grid grid-cols-6 gap-1 p-2 bg-black/40 rounded-lg border border-white/5 mb-3 text-center font-mono">
                        <div>
                          <span className="text-[9px] text-white/50 block">PAC</span>
                          <span className="text-xs font-bold text-[#ffd700]">{locker.pace}</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-white/50 block">SHO</span>
                          <span className="text-xs font-bold text-[#ffd700]">{locker.shooting}</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-white/50 block">PAS</span>
                          <span className="text-xs font-bold text-[#ffd700]">{locker.passing}</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-white/50 block">DRI</span>
                          <span className="text-xs font-bold text-[#ffd700]">{locker.dribbling}</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-white/50 block">DEF</span>
                          <span className="text-xs font-bold text-[#ffd700]">{locker.defending}</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-white/50 block">PHY</span>
                          <span className="text-xs font-bold text-[#ffd700]">{locker.physical}</span>
                        </div>
                      </div>

                      {/* Signature Trait */}
                      <div className="flex items-center gap-1.5 p-2 bg-[#00285e]/40 rounded-md border border-[#6cabdd]/30 mb-3 text-[11px] font-mono text-[#98c5e9]">
                        <Zap className="w-3.5 h-3.5 text-[#00e5ff] shrink-0" />
                        <span>{locker.signatureTrait}</span>
                      </div>
                    </div>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1 pt-2 border-t border-white/10">
                      {locker.keySkills.map((s) => (
                        <span
                          key={s}
                          className="px-2 py-0.5 text-[10px] font-mono font-medium bg-white/5 text-[#98c5e9] rounded border border-white/10"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </article>
                ))}
              </div>
            </section>
          )}

          {/* ============================================================ */}
          {/* SECTION 2: ARSIP TROFI PROYEK (ZONA 2 - TROPHY & VAR ROOM) */}
          {/* ============================================================ */}
          {(activeTab === "all" || activeTab === "projects") && (
            <section aria-labelledby="projects-section-heading" className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-mono text-xs text-[#ffd700] font-bold tracking-wider">
                    ZONE 02 // TROPHY & VAR ROOM
                  </span>
                  <h2 id="projects-section-heading" className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                    Showcase Rekayasa Sistem & Proyek Unggulan
                  </h2>
                </div>
                <span className="font-mono text-xs text-white/50 hidden sm:inline">
                  6 VERIFIED CASE STUDIES
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {STADIUM_TROPHIES.map((project) => (
                  <article
                    key={project.id}
                    className="bg-[#0b1422] border border-white/15 hover:border-[#6cabdd]/60 rounded-2xl p-5 shadow-xl transition-all flex flex-col justify-between group"
                  >
                    <div>
                      {/* Project Header */}
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-1.5 text-xs font-mono text-[#ffd700]">
                          <Trophy className="w-4 h-4" />
                          <span>{project.year}</span>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00285e] text-[#00e5ff] border border-[#6cabdd]/30">
                          {project.role}
                        </span>
                      </div>

                      <h3 className="text-xl font-bold text-white group-hover:text-[#00e5ff] transition-colors mb-1">
                        {project.title}
                      </h3>
                      <p className="text-xs font-mono text-white/50 mb-3">
                        {project.type} ({project.team})
                      </p>

                      <p className="text-xs text-white/80 leading-relaxed mb-4">
                        {project.description}
                      </p>

                      {/* 3 Metrics */}
                      <div className="grid grid-cols-3 gap-1.5 p-2 bg-black/40 rounded-lg border border-white/5 mb-4 text-center font-mono">
                        {project.metrics.map((m) => (
                          <div key={`${project.id}-metric-${m.label}`}>
                            <span className="text-xs font-bold text-[#ffd700] block">{m.value}</span>
                            <span className="text-[9px] text-white/50 block truncate">{m.label}</span>
                          </div>
                        ))}
                      </div>

                      {/* Tactical Highlights */}
                      <div className="space-y-1 mb-4 text-xs text-white/70">
                        {project.highlights.slice(0, 2).map((h) => (
                          <div key={`${project.id}-hl-${h.slice(0, 15)}`} className="flex items-start gap-1.5 text-[11px]">
                            <Sparkles className="w-3 h-3 text-[#00e5ff] shrink-0 mt-0.5" />
                            <span>{h}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Action Links */}
                    <div className="pt-3 border-t border-white/10 space-y-2">
                      <div className="flex flex-wrap gap-1">
                        {project.tags.map((t) => (
                          <span
                            key={t}
                            className="px-2 py-0.5 text-[10px] font-mono bg-white/5 text-[#98c5e9] rounded"
                          >
                            {t}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-2">
                          {project.liveUrl && (
                            <a
                              href={project.liveUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-white/70 hover:text-[#00e5ff] transition-colors"
                              title="Live Deployment"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          )}
                          {project.repoUrl && (
                            <a
                              href={project.repoUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-white/70 hover:text-white transition-colors"
                              title="GitHub Repository"
                            >
                              <GitBranch className="w-4 h-4" />
                            </a>
                          )}
                        </div>

                        <Link
                          href={project.detailHref}
                          className="flex items-center gap-1 font-mono text-xs font-bold text-[#6cabdd] hover:text-[#00e5ff] transition-colors"
                        >
                          <span>DETAIL STUDI KASUS</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </Link>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          )}

          {/* ============================================================ */}
          {/* SECTION 3: TIMELINE PENGALAMAN (ZONA 3 - THE GLASS TUNNEL) */}
          {/* ============================================================ */}
          {(activeTab === "all" || activeTab === "career") && (
            <section aria-labelledby="career-section-heading" className="space-y-4">
              <div>
                <span className="font-mono text-xs text-[#6cabdd] font-bold tracking-wider">
                  ZONE 03 // THE GLASS TUNNEL
                </span>
                <h2 id="career-section-heading" className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                  Garis Waktu Pengalaman & Riset Akademik
                </h2>
              </div>

              <div className="space-y-4">
                {STADIUM_MILESTONES.map((milestone) => (
                  <article
                    key={milestone.id}
                    className="bg-[#0b1422] border border-white/10 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row md:items-start justify-between gap-6"
                  >
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2 text-xs font-mono text-[#00e5ff]">
                        {getMilestoneIcon(milestone.type)}
                        <span className="font-bold uppercase">{milestone.type}</span>
                        <span className="text-white/40">|</span>
                        <span className="text-white/70">{milestone.period}</span>
                      </div>

                      <h3 className="text-xl font-bold text-white">
                        {milestone.role}
                      </h3>
                      <p className="text-xs font-mono text-[#98c5e9]">
                        {milestone.organization}
                      </p>

                      <p className="text-xs text-white/80 leading-relaxed pt-1">
                        {milestone.summary}
                      </p>

                      <ul className="space-y-1 pt-2">
                        {milestone.deliverables.map((item) => (
                          <li key={`${milestone.id}-deliv-${item.slice(0, 15)}`} className="flex items-start gap-2 text-xs text-white/75">
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#00e5ff] shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {milestone.telemetryMetric && (
                      <div className="shrink-0 p-3 bg-[#050911] border border-white/10 rounded-xl text-center font-mono">
                        <span className="text-[10px] text-white/40 block mb-0.5">TELEMETRY</span>
                        <span className="text-xs font-bold text-emerald-400 block">
                          {milestone.telemetryMetric}
                        </span>
                      </div>
                    )}
                  </article>
                ))}
              </div>
            </section>
          )}

          {/* ============================================================ */}
          {/* SECTION 4: KICK-OFF & HUB KONTAK (ZONA 4 - THE PITCH) */}
          {/* ============================================================ */}
          {(activeTab === "all" || activeTab === "contact") && (
            <section aria-labelledby="contact-section-heading" className="bg-[#0b1422] border-2 border-[#00e5ff]/40 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="space-y-1">
                <span className="font-mono text-xs text-[#00e5ff] font-bold tracking-wider">
                  ZONE 04 // THE PITCH & JUMBOTRON
                </span>
                <h2 id="contact-section-heading" className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                  Kick-Off Matchday Collaboration
                </h2>
                <p className="text-xs sm:text-sm text-white/70 font-mono">
                  Terbuka untuk posisi Software Engineer, Fullstack Developer, Mobile App Specialist, atau diskusi riset sistem terdistribusi & IoT.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-[#111e30] hover:bg-[#1a2d47] border border-white/10 rounded-xl flex items-center justify-center gap-2 font-mono text-xs font-bold text-white transition-all shadow-md"
                >
                  <LinkedinIcon className="w-4 h-4 text-[#00e5ff]" />
                  <span>LINKEDIN</span>
                </a>

                <a
                  href="https://github.com/tjhhh"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-[#111e30] hover:bg-[#1a2d47] border border-white/10 rounded-xl flex items-center justify-center gap-2 font-mono text-xs font-bold text-white transition-all shadow-md"
                >
                  <GithubIcon className="w-4 h-4 text-[#98c5e9]" />
                  <span>GITHUB</span>
                </a>

                <a
                  href="mailto:nhqkb@example.com"
                  className="p-3 bg-[#111e30] hover:bg-[#1a2d47] border border-white/10 rounded-xl flex items-center justify-center gap-2 font-mono text-xs font-bold text-white transition-all shadow-md"
                >
                  <Mail className="w-4 h-4 text-[#ffd700]" />
                  <span>EMAIL RESMI</span>
                </a>

                <a
                  href="/resume.pdf"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-[#00285e] hover:bg-[#003882] border border-[#6cabdd]/50 rounded-xl flex items-center justify-center gap-2 font-mono text-xs font-bold text-white transition-all shadow-md"
                >
                  <FileDown className="w-4 h-4 text-[#00e5ff]" />
                  <span>RESUME PDF</span>
                </a>
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
