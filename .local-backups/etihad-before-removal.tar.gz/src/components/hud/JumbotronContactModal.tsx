"use client";

import React, { useEffect, useState } from "react";
import confetti from "canvas-confetti";
import { useStadiumStore } from "@/store/useStadiumStore";
import {
  X,
  Send,
  Mail,
  MessageSquare,
  FileDown,
  CheckCircle2,
  Trophy,
} from "lucide-react";
import { GithubIcon, LinkedinIcon } from "@/components/ui/BrandIcons";

export function JumbotronContactModal() {
  const isJumbotronActive = useStadiumStore((s) => s.isJumbotronActive);
  const closeJumbotron = useStadiumStore((s) => s.closeJumbotron);

  const [formState, setFormState] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Trigger Goal Confetti on open
  useEffect(() => {
    if (isJumbotronActive) {
      try {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 },
          colors: ["#6CABDD", "#00E5FF", "#FFD700", "#FFFFFF", "#00285E"],
        });
      } catch {
        // Fallback gracefully if canvas context is unavailable
      }
    }
  }, [isJumbotronActive]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeJumbotron();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [closeJumbotron]);

  if (!isJumbotronActive) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    // Prepare direct mailto URL
    const mailto = `mailto:nhqkb@example.com?subject=Matchday Collaboration - ${encodeURIComponent(
      formState.name
    )}&body=${encodeURIComponent(formState.message)}%0A%0AFrom: ${encodeURIComponent(
      formState.email
    )}`;
    window.open(mailto, "_blank");
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Matchday Collaboration"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={closeJumbotron}
    >
      <div
        className="relative max-w-xl w-full bg-[#0a121e] border-2 border-[#00e5ff]/50 rounded-2xl shadow-[0_0_60px_rgba(0,229,255,0.3)] overflow-hidden select-none"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Jumbotron Goal Celebration Banner */}
        <div className="bg-gradient-to-r from-[#00285e] via-[#6cabdd] to-[#00285e] p-5 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px] opacity-25" />

          <button
            onClick={closeJumbotron}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/40 hover:bg-black/60 text-white transition-all z-10"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black/40 border border-white/20 mb-2">
            <Trophy className="w-4 h-4 text-[#ffd700]" />
            <span className="font-mono text-xs font-black text-white tracking-widest">
              KICK-OFF COMPLETE
            </span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight drop-shadow-md">
            GOAL // FULL-TIME COLLABORATION!
          </h2>
          <p className="font-mono text-xs text-white/90 mt-1 max-w-md mx-auto">
            Bola berhasil meluncur ke gawang Jumbotron. Mari diskusikan proyek rekayasa sistem, arsitektur backend, atau platform mobile Anda.
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {/* Direct Contact Channels */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-lg bg-[#111e30] hover:bg-[#1a2d47] border border-white/10 hover:border-[#00e5ff]/40 text-center flex flex-col items-center gap-1 text-white transition-all"
            >
              <LinkedinIcon className="w-4 h-4 text-[#00e5ff]" />
              <span className="font-mono text-[10px] font-bold">LINKEDIN</span>
            </a>

            <a
              href="https://github.com/tjhhh"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-lg bg-[#111e30] hover:bg-[#1a2d47] border border-white/10 hover:border-[#00e5ff]/40 text-center flex flex-col items-center gap-1 text-white transition-all"
            >
              <GithubIcon className="w-4 h-4 text-[#98c5e9]" />
              <span className="font-mono text-[10px] font-bold">GITHUB</span>
            </a>

            <a
              href="https://wa.me/628123456789"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-lg bg-[#111e30] hover:bg-[#1a2d47] border border-white/10 hover:border-[#00e5ff]/40 text-center flex flex-col items-center gap-1 text-white transition-all"
            >
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span className="font-mono text-[10px] font-bold">WHATSAPP</span>
            </a>

            <a
              href="/resume.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-lg bg-[#111e30] hover:bg-[#1a2d47] border border-white/10 hover:border-[#ffd700]/40 text-center flex flex-col items-center gap-1 text-white transition-all"
            >
              <FileDown className="w-4 h-4 text-[#ffd700]" />
              <span className="font-mono text-[10px] font-bold">RESUME PDF</span>
            </a>
          </div>

          {/* Quick Inquiry Form */}
          {isSubmitted ? (
            <div className="p-4 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <h3 className="font-bold text-white text-base">Pesan Telah Diteruskan!</h3>
              <p className="text-xs text-white/70 font-mono">
                Klien email Anda telah terbuka. Saya akan merespons dalam waktu 1x24 jam.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-mono text-white/70">
                <Mail className="w-3.5 h-3.5 text-[#00e5ff]" />
                <span>FORMULIR PESAN LANGSUNG:</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-mono text-[10px] text-white/50 block mb-1">
                    NAMA / PERUSAHAAN
                  </label>
                  <input
                    type="text"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    placeholder="e.g. Manchester Recruiter / CTO"
                    className="w-full px-3 py-2 bg-[#060c14] border border-white/15 focus:border-[#00e5ff] rounded-lg text-xs text-white placeholder-white/30 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="font-mono text-[10px] text-white/50 block mb-1">
                    EMAIL KONTAK
                  </label>
                  <input
                    type="email"
                    required
                    value={formState.email}
                    onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                    placeholder="name@company.com"
                    className="w-full px-3 py-2 bg-[#060c14] border border-white/15 focus:border-[#00e5ff] rounded-lg text-xs text-white placeholder-white/30 outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="font-mono text-[10px] text-white/50 block mb-1">
                  PESAN / KEBUTUHAN SISTEM
                </label>
                <textarea
                  required
                  rows={3}
                  value={formState.message}
                  onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                  placeholder="Ceritakan proyek perangkat lunak, tantangan teknis, atau peluang kolaborasi Anda..."
                  className="w-full px-3 py-2 bg-[#060c14] border border-white/15 focus:border-[#00e5ff] rounded-lg text-xs text-white placeholder-white/30 outline-none font-mono resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#00e5ff] hover:bg-[#6cabdd] text-[#070c14] font-mono text-xs font-black tracking-wider rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#00e5ff]/20"
              >
                <Send className="w-4 h-4" />
                <span>KIRIM PESAN SEKARANG</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
