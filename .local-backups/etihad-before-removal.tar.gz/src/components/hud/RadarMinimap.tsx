"use client";

import React, { useEffect } from "react";
import { useStadiumStore } from "@/store/useStadiumStore";
import type { StadiumZone } from "@/types/stadium";
import { Compass, Shirt, Video, Footprints, Flame } from "lucide-react";

export function RadarMinimap() {
  const viewMode = useStadiumStore((s) => s.viewMode);
  const activeZone = useStadiumStore((s) => s.activeZone);
  const setActiveZone = useStadiumStore((s) => s.setActiveZone);
  const playerCoordinates = useStadiumStore((s) => s.playerCoordinates);
  const playerHeading = useStadiumStore((s) => s.playerHeading);
  const ballCoordinates = useStadiumStore((s) => s.ballCoordinates);
  const setPlayerCoordinates = useStadiumStore((s) => s.setPlayerCoordinates);

  const zones: {
    id: StadiumZone;
    label: string;
    keyNum: string;
    icon: React.ReactNode;
    targetX: number;
    targetZ: number;
  }[] = [
    {
      id: "dressing-room",
      label: "DRESSING",
      keyNum: "1",
      icon: <Shirt className="w-3 h-3" />,
      targetX: -20,
      targetZ: 0,
    },
    {
      id: "var-room",
      label: "VAR ROOM",
      keyNum: "2",
      icon: <Video className="w-3 h-3" />,
      targetX: -8,
      targetZ: 0,
    },
    {
      id: "glass-tunnel",
      label: "TUNNEL",
      keyNum: "3",
      icon: <Footprints className="w-3 h-3" />,
      targetX: 4,
      targetZ: 0,
    },
    {
      id: "pitch",
      label: "THE PITCH",
      keyNum: "4",
      icon: <Flame className="w-3 h-3" />,
      targetX: 18,
      targetZ: 0,
    },
  ];

  // Map 3D X coordinates [-25, 28] to percentage [6%, 94%]
  const mapXToPercent = (x: number) => {
    const minX = -25;
    const maxX = 28;
    return Math.min(94, Math.max(6, ((x - minX) / (maxX - minX)) * 88 + 6));
  };

  // Map 3D Z coordinates [-6, 6] to percentage [15%, 85%]
  const mapZToPercent = (z: number) => {
    const minZ = -6;
    const maxZ = 6;
    return Math.min(85, Math.max(15, ((z - minZ) / (maxZ - minZ)) * 70 + 15));
  };

  const handleZoneClick = (target: { id: StadiumZone; targetX: number; targetZ: number }) => {
    setActiveZone(target.id);
    setPlayerCoordinates([target.targetX, 0, target.targetZ]);
  };

  // Keyboard shortcut listener [1], [2], [3], [4]
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (["INPUT", "TEXTAREA"].includes((e.target as HTMLElement)?.tagName)) return;
      if (e.key === "1") handleZoneClick(zones[0]);
      else if (e.key === "2") handleZoneClick(zones[1]);
      else if (e.key === "3") handleZoneClick(zones[2]);
      else if (e.key === "4") handleZoneClick(zones[3]);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [setActiveZone, setPlayerCoordinates]);

  // Convert 3D heading to 2D angle for FOV cone
  // dx = sin(heading), dz = cos(heading)
  const radarAngleDeg =
    Math.atan2(Math.cos(playerHeading), Math.sin(playerHeading)) * (180 / Math.PI);

  const playerXPercent = mapXToPercent(playerCoordinates[0]);
  const playerZPercent = mapZToPercent(playerCoordinates[2]);

  if (viewMode === "tactical-2d") return null;

  return (
    <aside aria-label="Etihad Tactical Radar" className="fixed bottom-4 left-4 z-40 select-none">
      <div className="bg-[#0a1224]/95 backdrop-blur-md border border-[#38bdf8]/35 p-3 rounded-xl shadow-[0_8px_32px_rgba(0,0,0,0.6)] w-80 sm:w-88">
        {/* Radar Header */}
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-[#00e5ff] animate-spin" style={{ animationDuration: "14s" }} />
            <span className="font-mono text-xs font-black text-white tracking-wider">
              ETIHAD TACTICAL RADAR
            </span>
          </div>
          <span className="font-mono text-[9px] text-[#38bdf8] font-bold bg-[#00285e]/80 px-2 py-0.5 rounded border border-[#38bdf8]/30">
            KEYS [1] - [4] JUMP
          </span>
        </div>

        {/* 2D Mini-Pitch Radar with Delicate Football Field Markings */}
        <div className="relative h-24 w-full bg-[#050c18] rounded-lg border border-white/10 overflow-hidden mb-2.5">
          {/* Subtle grass shade bands */}
          <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(255,255,255,0.015)_50%,transparent_50%)] bg-[length:32px_100%]" />

          {/* Outer Pitch Boundary Lines */}
          <div className="absolute inset-1.5 border border-white/20 rounded pointer-events-none" />

          {/* Halfway Line & Center Circle in Zone 3/4 */}
          <div className="absolute inset-y-1.5 left-1/2 w-px bg-white/20 pointer-events-none" />
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full border border-white/20 pointer-events-none flex items-center justify-center">
            <div className="w-1 h-1 rounded-full bg-white/40" />
          </div>

          {/* Zone Dividers (Cutaways) */}
          <div className="absolute inset-y-0 left-[25%] w-px border-r border-dashed border-[#38bdf8]/30 pointer-events-none" />
          <div className="absolute inset-y-0 left-[50%] w-px border-r border-dashed border-[#38bdf8]/30 pointer-events-none" />
          <div className="absolute inset-y-0 left-[75%] w-px border-r border-dashed border-[#38bdf8]/30 pointer-events-none" />

          {/* Left Penalty Box (Dressing Room side) */}
          <div className="absolute top-1/2 -translate-y-1/2 left-1.5 w-6 h-12 border border-l-0 border-white/15 pointer-events-none" />

          {/* Right Goal Box (Pitch Jumbotron side) */}
          <div className="absolute top-1/2 -translate-y-1/2 right-1.5 w-6 h-12 border border-r-0 border-white/15 pointer-events-none" />

          {/* Real-time Field-Of-View (FOV) Directional Cone */}
          <div
            className="absolute pointer-events-none z-10 transition-all duration-75"
            style={{
              left: `${playerXPercent}%`,
              top: `${playerZPercent}%`,
            }}
          >
            <svg
              className="absolute -top-7 -left-7 w-14 h-14"
              style={{
                transform: `rotate(${radarAngleDeg}deg)`,
                transformOrigin: "28px 28px",
              }}
              viewBox="0 0 56 56"
            >
              <defs>
                <radialGradient id="fovConeGrad" cx="0%" cy="50%" r="100%">
                  <stop offset="0%" stopColor="#00e5ff" stopOpacity="0.8" />
                  <stop offset="60%" stopColor="#38bdf8" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
                </radialGradient>
              </defs>
              <path d="M 28 28 L 56 16 A 28 28 0 0 1 56 40 Z" fill="url(#fovConeGrad)" />
            </svg>
          </div>

          {/* Real-time Player #17 Indicator Dot */}
          <div
            className="absolute w-4 h-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#00e5ff] border-2 border-white shadow-[0_0_12px_#00e5ff] transition-all duration-75 flex items-center justify-center pointer-events-none z-20"
            style={{
              left: `${playerXPercent}%`,
              top: `${playerZPercent}%`,
            }}
          >
            <span className="text-[7px] font-black text-black leading-none select-none">17</span>
          </div>

          {/* Real-time Soccer Ball Indicator Dot */}
          <div
            className="absolute w-2 h-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white border border-black shadow-[0_0_6px_white] transition-all duration-75 pointer-events-none z-20"
            style={{
              left: `${mapXToPercent(ballCoordinates[0])}%`,
              top: `${mapZToPercent(ballCoordinates[2])}%`,
            }}
          />

          {/* Zone Clickable Hitboxes */}
          <div className="absolute inset-0 grid grid-cols-4 z-0">
            {zones.map((z) => (
              <button
                key={z.id}
                onClick={() => handleZoneClick(z)}
                className={`h-full transition-colors flex items-end justify-center pb-1 cursor-pointer ${
                  activeZone === z.id
                    ? "bg-[#38bdf8]/15 border-b-2 border-[#00e5ff]"
                    : "hover:bg-white/5"
                }`}
                title={`Jump to ${z.label} [Shortcut: ${z.keyNum}]`}
              >
                <span className="font-mono text-[9px] font-bold text-white/50 tracking-tighter">
                  Z{z.keyNum}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* 4 Zone Teleport Buttons with Micro Icons & Hotkeys */}
        <div className="grid grid-cols-4 gap-1.5">
          {zones.map((z) => {
            const isCurrent = activeZone === z.id;
            return (
              <button
                key={z.id}
                onClick={() => handleZoneClick(z)}
                className={`py-1.5 px-1 rounded-md flex flex-col items-center justify-center font-mono transition-all text-center cursor-pointer ${
                  isCurrent
                    ? "bg-[#00285e] text-[#00e5ff] border border-[#00e5ff]/60 shadow-[0_0_10px_rgba(0,229,255,0.25)] ring-1 ring-[#00e5ff]/40"
                    : "bg-[#0a1424] text-white/70 hover:text-white hover:bg-[#111e33] border border-white/10"
                }`}
                title={`Shortcut: Press [${z.keyNum}]`}
              >
                <div className="flex items-center gap-1 mb-0.5">
                  <span className="text-[#38bdf8]">{z.icon}</span>
                  <span className="text-[9px] font-black text-amber-400">[{z.keyNum}]</span>
                </div>
                <span className="text-[9px] font-bold truncate w-full tracking-tight">
                  {z.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </aside>
  );
}
