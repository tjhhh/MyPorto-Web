"use client";

import React, { useEffect, useState } from "react";
import { useStadiumStore } from "@/store/useStadiumStore";
import { MousePointerClick, X } from "lucide-react";

export function OnboardingTooltip() {
  const hasSeenOnboarding = useStadiumStore((s) => s.hasSeenOnboarding);
  const dismissOnboarding = useStadiumStore((s) => s.dismissOnboarding);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!hasSeenOnboarding) {
      const timer = setTimeout(() => setVisible(true), 1200);
      const autoDismiss = setTimeout(() => {
        setVisible(false);
        dismissOnboarding();
      }, 7500);
      return () => {
        clearTimeout(timer);
        clearTimeout(autoDismiss);
      };
    }
  }, [hasSeenOnboarding, dismissOnboarding]);

  if (!visible) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 max-w-md w-[90%] select-none animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="bg-[#0a121e]/95 backdrop-blur-md border border-[#00e5ff]/50 rounded-xl p-3 shadow-2xl shadow-black/80 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-xs font-mono text-white/90">
          <div className="p-1.5 rounded bg-[#00285e] text-[#00e5ff] shrink-0">
            <MousePointerClick className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-[#00e5ff] block">
              CARA MENJELAJAHI ETIHAD:
            </span>
            <span className="text-white/70 text-[11px] leading-tight">
              Klik objek interaktif untuk langsung membuka detail, gunakan WASD untuk jalan, atau klik [Tactical 2D] untuk tampilan cepat.
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            setVisible(false);
            dismissOnboarding();
          }}
          className="p-1 text-white/50 hover:text-white rounded hover:bg-white/10 shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
