"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useStadiumStore } from "@/store/useStadiumStore";
import {
  X,
  Tv,
  GitBranch,
  ExternalLink,
  ChevronRight,
  Database,
  Server,
  Smartphone,
  Gauge,
  Sparkles,
  Trophy,
} from "lucide-react";

export function VARReviewModal() {
  const selectedTrophy = useStadiumStore((s) => s.selectedTrophy);
  const closeTrophy = useStadiumStore((s) => s.closeTrophy);

  const [activeTab, setActiveTab] = useState<"highlights" | "tactical" | "stats">("highlights");

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeTrophy();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [closeTrophy]);

  if (!selectedTrophy) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`VAR Review: ${selectedTrophy.title}`}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Escape") closeTrophy();
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 outline-none"
      onClick={closeTrophy}
    >
      <div
        role="document"
        tabIndex={0}
        onKeyDown={(e) => e.stopPropagation()}
        className="relative max-w-2xl w-full bg-[#0a121e] border border-[#6cabdd]/40 rounded-2xl shadow-[0_0_50px_rgba(108,171,221,0.2)] overflow-hidden select-none flex flex-col max-h-[90vh] outline-none"
        onClick={(e) => e.stopPropagation()}
      >
        {/* VAR Monitor Frame Header */}
        <div className="bg-[#050911] px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-600/20 border border-red-500/40">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span className="font-mono text-[11px] font-black text-red-400 tracking-wider">
                VAR REVIEW // OFFICIAL INSPECTION
              </span>
            </div>
            <span className="text-white/40 font-mono text-xs hidden sm:inline">|</span>
            <span className="font-mono text-xs text-[#00e5ff] font-bold">
              CASE #{selectedTrophy.id.toUpperCase()}
            </span>
          </div>

          <button
            onClick={closeTrophy}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Project Title & Metadata Bar */}
        <div className="px-5 py-4 border-b border-white/10 flex items-start justify-between bg-gradient-to-r from-[#00285e]/40 to-transparent">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Trophy className="w-4 h-4 text-[#ffd700]" />
              <span className="text-xs font-mono font-medium text-[#98c5e9]">
                {selectedTrophy.type} ({selectedTrophy.year})
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              {selectedTrophy.title}
            </h2>
            <p className="text-xs font-mono text-white/60 mt-0.5">
              Role: <span className="text-[#00e5ff]">{selectedTrophy.role}</span>{" // "}Team: {selectedTrophy.team}
            </p>
          </div>

          <div className="hidden sm:flex flex-col items-end">
            <span className="font-mono text-[10px] text-white/40">MATCH VERDICT</span>
            <span className="font-mono text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
              GOAL VALID // PRODUCTION READY
            </span>
          </div>
        </div>

        {/* VAR Interactive Tabs */}
        <div className="flex border-b border-white/10 bg-[#070d16] px-5">
          <button
            onClick={() => setActiveTab("highlights")}
            className={`px-4 py-2.5 font-mono text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === "highlights"
                ? "border-[#00e5ff] text-[#00e5ff] bg-[#00285e]/30"
                : "border-transparent text-white/60 hover:text-white"
            }`}
          >
            <Tv className="w-3.5 h-3.5" />
            MATCH HIGHLIGHTS
          </button>

          <button
            onClick={() => setActiveTab("tactical")}
            className={`px-4 py-2.5 font-mono text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === "tactical"
                ? "border-[#00e5ff] text-[#00e5ff] bg-[#00285e]/30"
                : "border-transparent text-white/60 hover:text-white"
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            TACTICAL ARCHITECTURE
          </button>

          <button
            onClick={() => setActiveTab("stats")}
            className={`px-4 py-2.5 font-mono text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === "stats"
                ? "border-[#00e5ff] text-[#00e5ff] bg-[#00285e]/30"
                : "border-transparent text-white/60 hover:text-white"
            }`}
          >
            <Gauge className="w-3.5 h-3.5" />
            MATCH STATS & SPECS
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {activeTab === "highlights" && (
            <div className="space-y-4">
              {/* Media Thumbnail */}
              <div className="relative w-full h-52 rounded-xl overflow-hidden border border-white/10 bg-black/50 group">
                <Image
                  src={selectedTrophy.image}
                  alt={selectedTrophy.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                  <span className="font-mono text-xs bg-black/60 px-2 py-1 rounded backdrop-blur text-white/90 border border-white/20">
                    4K REPLAY INSPECTION
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-white/85 leading-relaxed">
                {selectedTrophy.description}
              </p>

              {/* Tactical Highlights Bullet Points */}
              <div className="space-y-2">
                <span className="font-mono text-xs text-[#6cabdd] font-bold">
                  TACTICAL DECISIONS & HIGHLIGHTS:
                </span>
                <ul className="space-y-1.5">
                  {selectedTrophy.highlights.map((h) => (
                    <li key={`${selectedTrophy.id}-hl-${h.slice(0, 15)}`} className="flex items-start gap-2 text-xs text-white/80">
                      <Sparkles className="w-3.5 h-3.5 text-[#00e5ff] shrink-0 mt-0.5" />
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Tech Stack Chips */}
              <div className="pt-2">
                <span className="font-mono text-xs text-white/50 block mb-1.5">
                  DEPLOYED TECHNOLOGIES:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedTrophy.tags.map((t) => (
                    <span
                      key={t}
                      className="px-2.5 py-1 text-xs font-mono font-medium bg-[#111e30] text-[#98c5e9] rounded border border-[#6cabdd]/30"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === "tactical" && (
            <div className="space-y-4">
              <p className="text-xs text-white/70">
                Diagram alur data dan arsitektur sistem dari klien, gateway, hingga layer persistensi:
              </p>

              {/* Tactical Architecture Schematic Diagram */}
              <div className="space-y-3 font-mono text-xs">
                {/* Layer 1: Client UI */}
                <div className="p-3 bg-[#0d1624] rounded-lg border border-[#00e5ff]/30 flex items-start gap-3">
                  <div className="p-2 rounded bg-[#00285e] text-[#00e5ff]">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-white/50 text-[10px] uppercase block">
                      Layer 01 // Client & Mobile Interface
                    </span>
                    <span className="text-white font-bold">
                      {selectedTrophy.tacticalArchitecture.frontend}
                    </span>
                  </div>
                </div>

                <div className="flex justify-center text-[#6cabdd]">↓ HTTP / REST / WebSockets ↓</div>

                {/* Layer 2: Backend */}
                <div className="p-3 bg-[#0d1624] rounded-lg border border-[#6cabdd]/30 flex items-start gap-3">
                  <div className="p-2 rounded bg-[#00285e] text-[#6cabdd]">
                    <Server className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-white/50 text-[10px] uppercase block">
                      Layer 02 // Application Server & Microservices
                    </span>
                    <span className="text-white font-bold">
                      {selectedTrophy.tacticalArchitecture.backend}
                    </span>
                  </div>
                </div>

                <div className="flex justify-center text-[#6cabdd]">↓ SQL Transactions & Queries ↓</div>

                {/* Layer 3: Persistence & Telemetry */}
                <div className="p-3 bg-[#0d1624] rounded-lg border border-[#ffd700]/30 flex items-start gap-3">
                  <div className="p-2 rounded bg-[#332a00] text-[#ffd700]">
                    <Database className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-white/50 text-[10px] uppercase block">
                      Layer 03 // Persistence Pipeline & Ingestion
                    </span>
                    <span className="text-white font-bold">
                      {selectedTrophy.tacticalArchitecture.dataPipeline}
                    </span>
                  </div>
                </div>
              </div>

              {/* Infrastructure Note */}
              <div className="p-3 bg-white/5 rounded-lg border border-white/10 text-xs text-white/80">
                <span className="font-mono text-[#00e5ff] font-bold block mb-1">
                  INFRASTRUCTURE & HOSTING:
                </span>
                {selectedTrophy.tacticalArchitecture.infrastructure}
              </div>
            </div>
          )}

          {activeTab === "stats" && (
            <div className="space-y-4">
              {/* Metrics Grid */}
              <div className="grid grid-cols-3 gap-3">
                {selectedTrophy.metrics.map((m) => (
                  <div
                    key={`${selectedTrophy.id}-metric-${m.label}`}
                    className="p-3 bg-[#0c1524] rounded-xl border border-white/10 text-center"
                  >
                    <span className="font-mono text-xl font-bold text-[#ffd700] block">
                      {m.value}
                    </span>
                    <span className="font-mono text-[10px] text-white/60 uppercase">
                      {m.label}
                    </span>
                  </div>
                ))}
              </div>

              {/* Action Links */}
              <div className="space-y-2 pt-2">
                <span className="font-mono text-xs text-white/50 block">DIRECT ARTIFACT ACCESS:</span>
                <div className="flex flex-col sm:flex-row gap-2">
                  {selectedTrophy.liveUrl && (
                    <a
                      href={selectedTrophy.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-[#00e5ff] hover:bg-[#6cabdd] text-black font-mono text-xs font-bold rounded-lg transition-all shadow-md"
                    >
                      <ExternalLink className="w-4 h-4" />
                      OPEN LIVE DEPLOYMENT
                    </a>
                  )}

                  {selectedTrophy.repoUrl && (
                    <a
                      href={selectedTrophy.repoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-[#162032] hover:bg-[#1f2d47] text-white font-mono text-xs font-bold rounded-lg border border-white/15 transition-all"
                    >
                      <GitBranch className="w-4 h-4 text-[#6cabdd]" />
                      INSPECT SOURCE REPO
                    </a>
                  )}

                  <Link
                    href={selectedTrophy.detailHref}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-mono text-xs font-bold rounded-lg border border-white/15 transition-all"
                  >
                    <span>DEEP MONOGRAPH</span>
                    <ChevronRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-[#050911] px-5 py-3 border-t border-white/10 flex items-center justify-between font-mono text-xs">
          <span className="text-white/40">ETIHAD TROPHY ARCHIVE // #17</span>
          <button
            onClick={closeTrophy}
            className="px-4 py-1.5 bg-white/10 hover:bg-white/20 text-white font-mono text-xs font-semibold rounded transition-all"
          >
            CLOSE VAR REVIEW
          </button>
        </div>
      </div>
    </div>
  );
}
