"use client";

import React from "react";
import { useStadiumStore } from "@/store/useStadiumStore";
import {
  Volume2,
  VolumeX,
  FileDown,
  Box,
  Zap,
} from "lucide-react";

export function TopBar() {
  const viewMode = useStadiumStore((s) => s.viewMode);
  const toggleViewMode = useStadiumStore((s) => s.toggleViewMode);
  const activeZone = useStadiumStore((s) => s.activeZone);
  const audioEnabled = useStadiumStore((s) => s.audioEnabled);
  const toggleAudio = useStadiumStore((s) => s.toggleAudio);

  const zoneShortLabels: Record<string, string> = {
    "dressing-room": "Z1: DRESSING ROOM (SKILLS)",
    "var-room": "Z2: VAR & TROPHY ROOM",
    "glass-tunnel": "Z3: THE GLASS TUNNEL",
    "pitch": "Z4: THE PITCH & JUMBOTRON",
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-40 px-4 py-3 flex items-center justify-between pointer-events-none select-none">
      {/* Left: EA Sports FC / Premier League Broadcast Scorebug */}
      <div className="flex items-center gap-3 pointer-events-auto">
        <div className="flex items-center -skew-x-6 bg-[#0a1224]/95 backdrop-blur-md border border-[#38bdf8]/40 px-3.5 py-1.5 rounded shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
          <div className="skew-x-6 flex items-center gap-2 font-mono text-xs">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00e5ff] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00e5ff]" />
            </span>
            <span className="font-black text-[#38bdf8] tracking-wider">
              [MCY #17 | FAUZAN]
            </span>
            <span className="text-white/30 font-bold">|</span>
            <span className="text-white/95 font-bold tracking-wide">
              {zoneShortLabels[activeZone] || "Z4: THE PITCH"}
            </span>
          </div>
        </div>
      </div>

      {/* Right: High-contrast 2D Recruiter Sprint + Audio + CV */}
      <div className="flex items-center gap-2.5 pointer-events-auto">
        {/* Recruiter 2D View Switch Button (Max Contrast Gradient) */}
        <button
          onClick={toggleViewMode}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-xs font-black tracking-wider transition-all duration-200 cursor-pointer shadow-xl ${
            viewMode === "tactical-2d"
              ? "bg-[#00e5ff] text-[#070c14] hover:bg-[#38bdf8] shadow-[0_0_20px_rgba(0,229,255,0.4)] border border-white"
              : "bg-gradient-to-r from-[#0284c7] via-[#38bdf8] to-[#6366f1] text-white hover:brightness-110 shadow-[0_0_25px_rgba(56,189,248,0.45)] border border-white/50 ring-2 ring-[#38bdf8]/60 hover:scale-[1.02]"
          }`}
          title="Switch instantly between 3D Cutaway Diorama and 2D Tactical Strategy Board"
        >
          {viewMode === "tactical-2d" ? (
            <>
              <Box className="w-4 h-4 text-[#070c14]" />
              <span>RETURN TO 3D DIORAMA</span>
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 text-white fill-white animate-pulse" />
              <span>⚡ SWITCH TO 2D RECRUITER SPRINT</span>
            </>
          )}
        </button>

        {/* Audio FX Toggle */}
        <button
          onClick={toggleAudio}
          className={`p-2 rounded-lg border backdrop-blur-md transition-all cursor-pointer ${
            audioEnabled
              ? "bg-[#0a1224]/95 border-[#00e5ff]/60 text-[#00e5ff] shadow-[0_0_12px_rgba(0,229,255,0.3)]"
              : "bg-[#0a1224]/80 border-white/10 text-white/60 hover:text-white"
          }`}
          title={audioEnabled ? "Mute Stadium Ambiance" : "Enable Stadium Sound FX & Roar"}
        >
          {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Download Official CV */}
        <a
          href="/resume.pdf"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-3 py-2 bg-[#0f172a]/90 hover:bg-[#1e293b] text-white font-mono text-xs border border-white/15 hover:border-[#38bdf8]/50 rounded-lg transition-all shadow-md backdrop-blur-md cursor-pointer"
        >
          <FileDown className="w-3.5 h-3.5 text-[#f59e0b]" />
          <span className="hidden sm:inline font-bold">RESUME</span>
          <span className="font-bold">CV</span>
        </a>
      </div>
    </header>
  );
}
