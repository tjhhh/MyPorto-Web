"use client";

import React, { useEffect } from "react";
import { useStadiumStore } from "@/store/useStadiumStore";
import { fetchEtihadWeather, subscribeStadiumPresence } from "@/lib/telemetry";
import { Activity, Users, CloudSun } from "lucide-react";

export function TelemetryScoreboard() {
  const viewMode = useStadiumStore((s) => s.viewMode);
  const fps = useStadiumStore((s) => s.fps);
  const activeVisitors = useStadiumStore((s) => s.activeVisitors);
  const weather = useStadiumStore((s) => s.weatherCondition);
  const setActiveVisitors = useStadiumStore((s) => s.setActiveVisitors);
  const setWeather = useStadiumStore((s) => s.setWeather);

  // Initialize weather & presence telemetry
  useEffect(() => {
    fetchEtihadWeather().then((w) => setWeather(w));
    const unsubscribe = subscribeStadiumPresence((count) => {
      setActiveVisitors(count);
    });
    return () => unsubscribe();
  }, [setActiveVisitors, setWeather]);

  if (viewMode === "tactical-2d") return null;

  const fpsColor =
    fps >= 50 ? "text-emerald-400" : fps >= 30 ? "text-amber-400" : "text-red-400";

  return (
    <aside
      aria-label="Stadium Telemetry Single-Line Pill"
      className="fixed top-14 right-4 z-40 select-none hidden sm:block pointer-events-none"
    >
      <div className="flex items-center gap-3 px-3.5 py-1.5 rounded-full bg-[#0a1224]/75 backdrop-blur-md border border-[#38bdf8]/25 shadow-lg shadow-black/40 font-mono text-[11px] text-white/90">
        {/* FPS Indicator */}
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <Activity className="w-3.5 h-3.5 text-[#38bdf8]" />
          <span className={`font-black ${fpsColor}`}>{fps} FPS</span>
        </div>

        <span className="text-white/20">|</span>

        {/* Online Crowd Presence */}
        <div className="flex items-center gap-1.5">
          <Users className="w-3.5 h-3.5 text-[#f59e0b]" />
          <span className="font-bold text-white/90">{activeVisitors} ONLINE</span>
        </div>

        <span className="text-white/20">|</span>

        {/* Local Stadium Weather */}
        <div className="flex items-center gap-1.5">
          <CloudSun className="w-3.5 h-3.5 text-[#38bdf8]" />
          <span className="font-bold text-white/80">{weather.temp} SURABAYA</span>
        </div>
      </div>
    </aside>
  );
}
