"use client";

import React, { useEffect } from "react";
import { useStadiumStore } from "@/store/useStadiumStore";
import { X, ShieldCheck, Zap, Sparkles, Layers } from "lucide-react";

export function FUTCardModal() {
  const selectedLocker = useStadiumStore((s) => s.selectedLocker);
  const closeLocker = useStadiumStore((s) => s.closeLocker);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeLocker();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [closeLocker]);

  if (!selectedLocker) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={selectedLocker.badgeTitle}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={closeLocker}
    >
      <div
        className="relative max-w-lg w-full bg-gradient-to-b from-[#101b2b] via-[#09101d] to-[#05080e] border-2 border-[#ffd700]/60 rounded-2xl shadow-[0_0_50px_rgba(255,215,0,0.25)] p-6 overflow-hidden select-none"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Gold Holographic Ambient Foil Effect */}
        <div className="absolute -top-24 -right-24 w-60 h-60 bg-[#ffd700]/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-60 h-60 bg-[#00e5ff]/15 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Close Button */}
        <button
          onClick={closeLocker}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-all z-20"
        >
          <X className="w-5 h-5" />
        </button>

        {/* EA FC Ultimate Team Card Top Section */}
        <div className="flex items-start justify-between pb-4 border-b border-white/10">
          {/* Card OVR, Position, Nationality */}
          <div className="flex items-center gap-3">
            <div className="flex flex-col items-center">
              <span className="font-mono text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-[#ffd700] via-[#fff1a8] to-[#d4af37] leading-none">
                {selectedLocker.overallRating}
              </span>
              <span className="font-mono text-xs font-bold text-white/90 tracking-wider">
                {selectedLocker.position}
              </span>
              <span className="text-sm mt-0.5">🇮🇩</span>
            </div>

            <div className="h-10 w-px bg-white/15" />

            <div>
              <div className="flex items-center gap-1.5 text-[#ffd700]">
                <Sparkles className="w-4 h-4 fill-[#ffd700]" />
                <span className="font-mono text-[11px] font-black tracking-widest uppercase">
                  {selectedLocker.badgeTitle}
                </span>
              </div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                {selectedLocker.category}
              </h2>
            </div>
          </div>

          {/* Jersey Badge */}
          <div className="flex items-center justify-center w-11 h-11 rounded-lg bg-[#00285e] border border-[#6cabdd]/50 shadow-inner">
            <span className="font-mono text-lg font-black text-[#00e5ff]">
              #{selectedLocker.number}
            </span>
          </div>
        </div>

        {/* Signature Trait Banner */}
        <div className="my-4 px-3 py-2 bg-[#00285e]/40 border border-[#6cabdd]/30 rounded-lg flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#00e5ff] shrink-0" />
          <p className="text-xs font-mono font-medium text-[#98c5e9]">
            {selectedLocker.signatureTrait}
          </p>
        </div>

        {/* EA FC 6 Core Attributes Grid */}
        <div className="grid grid-cols-6 gap-2 my-4 p-3 bg-black/40 rounded-xl border border-white/5">
          {[
            { label: "PAC", val: selectedLocker.pace, title: "Speed & Frame Time" },
            { label: "SHO", val: selectedLocker.shooting, title: "Precision Delivery" },
            { label: "PAS", val: selectedLocker.passing, title: "System Integration" },
            { label: "DRI", val: selectedLocker.dribbling, title: "Responsive Fluidity" },
            { label: "DEF", val: selectedLocker.defending, title: "Security & Clean Code" },
            { label: "PHY", val: selectedLocker.physical, title: "High-Load Scalability" },
          ].map((stat) => (
            <div key={stat.label} className="flex flex-col items-center" title={stat.title}>
              <span className="font-mono text-xs text-white/50">{stat.label}</span>
              <span className="font-mono text-lg font-bold text-[#ffd700]">{stat.val}</span>
            </div>
          ))}
        </div>

        {/* Key Skills Tags */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-1.5 text-xs font-mono text-white/60">
            <Layers className="w-3.5 h-3.5 text-[#6cabdd]" />
            <span>CORE ARSENAL & TECHNOLOGIES</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {selectedLocker.keySkills.map((skill) => (
              <span
                key={skill}
                className="px-2.5 py-1 text-xs font-mono font-semibold bg-[#111d2e] text-[#6cabdd] rounded-md border border-[#6cabdd]/30"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>

        {/* Detailed Architectural Narrative */}
        <div className="p-3 bg-white/5 rounded-lg border border-white/10 mb-4">
          <p className="text-xs text-white/80 leading-relaxed">
            {selectedLocker.description}
          </p>
        </div>

        {/* Footer Card Actions */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-1 text-[11px] font-mono text-white/40">
            <ShieldCheck className="w-3.5 h-3.5 text-[#00e5ff]" />
            <span>VERIFIED FIRST-TEAM OPERATOR</span>
          </div>
          <button
            onClick={closeLocker}
            className="px-4 py-1.5 bg-[#ffd700] hover:bg-[#ffe14d] text-black font-mono text-xs font-bold rounded-md transition-all shadow-md"
          >
            DISMISS CARD
          </button>
        </div>
      </div>
    </div>
  );
}
