"use client";

import React, { useRef, useState, useEffect } from "react";
import { useStadiumStore } from "@/store/useStadiumStore";

export function VirtualJoystick() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  const viewMode = useStadiumStore((s) => s.viewMode);

  useEffect(() => {
    const isTouch = "ontouchstart" in window || navigator.maxTouchPoints > 0;
    if (isTouch) {
      const timer = setTimeout(() => setIsTouchDevice(true), 0);
      return () => clearTimeout(timer);
    }
  }, []);

  if (!isTouchDevice || viewMode === "tactical-2d") return null;

  const maxRadius = 38;

  const handleTouchStart = (e: React.TouchEvent) => {
    handleTouchMove(e);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!containerRef.current) return;
    const touch = e.touches[0];
    const rect = containerRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = touch.clientX - centerX;
    const dy = touch.clientY - centerY;
    const distance = Math.hypot(dx, dy);

    const clampedDist = Math.min(distance, maxRadius);
    const angle = Math.atan2(dy, dx);

    const knobX = Math.cos(angle) * clampedDist;
    const knobY = Math.sin(angle) * clampedDist;

    setKnobPos({ x: knobX, y: knobY });

    // Normalize joystick vector to [-1, 1]
    const normX = knobX / maxRadius;
    const normY = knobY / maxRadius;

    // Dispatched to player input if needed via DOM custom event
    const event = new CustomEvent("joystick-move", { detail: { x: normX, y: normY } });
    window.dispatchEvent(event);
  };

  const handleTouchEnd = () => {
    setKnobPos({ x: 0, y: 0 });
    const event = new CustomEvent("joystick-move", { detail: { x: 0, y: 0 } });
    window.dispatchEvent(event);
  };

  return (
    <div
      ref={containerRef}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
      className="fixed bottom-24 left-6 z-40 w-24 h-24 rounded-full bg-black/40 backdrop-blur border border-white/20 flex items-center justify-center touch-none select-none md:hidden"
    >
      <div
        className="w-10 h-10 rounded-full bg-[#00e5ff]/80 border-2 border-white shadow-lg pointer-events-none transition-transform duration-75"
        style={{
          transform: `translate(${knobPos.x}px, ${knobPos.y}px)`,
        }}
      />
    </div>
  );
}
