"use client";

import React, { useEffect } from "react";
import { useStadiumStore } from "@/store/useStadiumStore";
import { X, Briefcase, GraduationCap, CheckCircle, Award } from "lucide-react";

export function MilestoneModal() {
  const selectedMilestone = useStadiumStore((s) => s.selectedMilestone);
  const closeMilestone = useStadiumStore((s) => s.closeMilestone);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeMilestone();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [closeMilestone]);

  if (!selectedMilestone) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Milestone: ${selectedMilestone.role}`}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={closeMilestone}
    >
      <div
        className="relative max-w-lg w-full bg-[#0a121e] border border-[#6cabdd]/40 rounded-2xl shadow-[0_0_50px_rgba(108,171,221,0.2)] p-6 overflow-hidden select-none"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={closeMilestone}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Milestone Category & Institution */}
        <div className="flex items-center gap-2 mb-2 text-xs font-mono text-[#00e5ff]">
          {selectedMilestone.type.includes("Internship") ? (
            <Briefcase className="w-4 h-4" />
          ) : selectedMilestone.type.includes("Teaching") ? (
            <Award className="w-4 h-4" />
          ) : (
            <GraduationCap className="w-4 h-4" />
          )}
          <span className="uppercase font-bold tracking-wider">{selectedMilestone.type}</span>
          <span className="text-white/40">|</span>
          <span className="text-white/70">{selectedMilestone.period}</span>
        </div>

        <h2 className="text-xl font-bold text-white tracking-tight mb-1">
          {selectedMilestone.role}
        </h2>
        <p className="text-xs font-mono text-[#98c5e9] mb-4">
          {selectedMilestone.organization}
        </p>

        {/* Summary Description */}
        <div className="p-3 bg-[#00285e]/30 border border-[#6cabdd]/30 rounded-xl mb-4">
          <p className="text-xs text-white/90 leading-relaxed">
            {selectedMilestone.summary}
          </p>
        </div>

        {/* Deliverables & Impact */}
        <div className="space-y-2 mb-4">
          <span className="font-mono text-xs text-white/50 block">
            CORE IMPACT & RESPONSIBILITIES:
          </span>
          <ul className="space-y-2">
            {selectedMilestone.deliverables.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2 text-xs text-white/80">
                <CheckCircle className="w-3.5 h-3.5 text-[#00e5ff] shrink-0 mt-0.5" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Telemetry Metric Banner */}
        {selectedMilestone.telemetryMetric && (
          <div className="p-2.5 bg-black/40 border border-white/10 rounded-lg flex items-center justify-between text-xs font-mono">
            <span className="text-white/50">VERIFIED TELEMETRY:</span>
            <span className="text-emerald-400 font-bold">
              {selectedMilestone.telemetryMetric}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
