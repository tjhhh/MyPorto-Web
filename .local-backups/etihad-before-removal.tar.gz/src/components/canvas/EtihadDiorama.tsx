import * as THREE from "three";
import type { TrophyProject } from "@/types/stadium";

/**
 * Procedural Stylized Cel-Shaded 3D Diorama of Etihad Stadium
 * Features 4 interconnected cutaway zones:
 * 1. The Dressing Room (X: -24 to -14)
 * 2. Trophy & VAR Room (X: -14 to -2)
 * 3. The Glass Tunnel (X: -2 to 10)
 * 4. The Pitch & Jumbotron (X: 10 to 30)
 */

export interface DioramaInteractiveObjects {
  lockers: { id: "tiki-taka" | "engine" | "visionary"; mesh: THREE.Object3D; position: [number, number, number] }[];
  trophies: { id: string; mesh: THREE.Object3D; position: [number, number, number] }[];
  milestones: { id: string; mesh: THREE.Object3D; position: [number, number, number] }[];
  jumbotron: { mesh: THREE.Object3D; position: [number, number, number] };
  kickoffBallTarget: { mesh: THREE.Object3D; position: [number, number, number] };
  updateVarScreens?: (project: TrophyProject | null, time: number) => void;
}

// =========================================================================
// 6 BESPOKE 3D MINIATURE SCULPTURE BUILDERS FOR ZONE 02
// =========================================================================

// 1. SMART KANDANG: Gateway Node / Server Cube (Gold/Cyan)
function createSmartKandangSculpt(): THREE.Group {
  const g = new THREE.Group();
  const cubeMat = new THREE.MeshToonMaterial({ color: 0x0a1626 });
  const cube = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.85, 0.85), cubeMat);
  cube.position.y = 0.55;
  g.add(cube);

  const slitMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff });
  const frontSlit = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.06, 0.04), slitMat);
  frontSlit.position.set(0, 0.65, 0.44);
  g.add(frontSlit);

  const frontSlit2 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.06, 0.04), slitMat);
  frontSlit2.position.set(0, 0.45, 0.44);
  g.add(frontSlit2);

  const goldTrimMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
  const sideSlit = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.5, 0.04), goldTrimMat);
  sideSlit.position.set(0.44, 0.55, 0);
  g.add(sideSlit);

  // Antenna Spire
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.5, 8), goldTrimMat);
  antenna.position.set(0, 1.15, 0);
  g.add(antenna);

  // Pulsing LED Beacon
  const led = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), slitMat);
  led.position.set(0, 1.42, 0);
  g.add(led);

  // Rotating Concentric Telemetry Ring
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.68, 0.03, 8, 24), slitMat);
  ring.rotation.x = Math.PI * 0.35;
  ring.position.set(0, 0.55, 0);
  g.add(ring);

  return g;
}

// 2. FUTSALPRO: Mini Pitch Turf + Golden Faceted Ball + Goal Arc (Emerald)
function createFutsalProSculpt(): THREE.Group {
  const g = new THREE.Group();
  const turf = new THREE.Mesh(
    new THREE.BoxGeometry(1.2, 0.12, 0.85),
    new THREE.MeshToonMaterial({ color: 0x10b981 })
  );
  turf.position.y = 0.1;
  g.add(turf);

  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const centerLine = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.02, 0.82), lineMat);
  centerLine.position.set(0, 0.17, 0);
  g.add(centerLine);

  const centerCircle = new THREE.Mesh(new THREE.RingGeometry(0.18, 0.22, 16), lineMat);
  centerCircle.rotation.x = -Math.PI / 2;
  centerCircle.position.set(0, 0.175, 0);
  g.add(centerCircle);

  // Goal Wireframe Arc
  const goal = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.03, 6, 16, Math.PI), lineMat);
  goal.rotation.z = Math.PI;
  goal.rotation.y = Math.PI / 2;
  goal.position.set(0, 0.42, -0.36);
  g.add(goal);

  // Golden Faceted Soccer Ball
  const ball = new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.32, 1),
    new THREE.MeshToonMaterial({ color: 0xffd700 })
  );
  ball.position.set(0, 0.65, 0);
  g.add(ball);

  return g;
}

// 3. RIDEASSIST: Rotating Gear Ring + Speedometer Gauge (Orange/Red)
function createRideAssistSculpt(): THREE.Group {
  const g = new THREE.Group();
  const gearMat = new THREE.MeshToonMaterial({ color: 0x334155 });
  const ringMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.16, 24), gearMat);
  ringMesh.rotation.x = Math.PI / 2;
  ringMesh.position.y = 0.55;
  g.add(ringMesh);

  // 8 Gear Teeth
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.16, 0.15), gearMat);
    tooth.position.set(Math.cos(angle) * 0.62, 0.55, Math.sin(angle) * 0.62);
    tooth.rotation.y = -angle;
    g.add(tooth);
  }

  // Dial Face
  const dial = new THREE.Mesh(
    new THREE.CylinderGeometry(0.44, 0.44, 0.17, 24),
    new THREE.MeshBasicMaterial({ color: 0x050a14 })
  );
  dial.rotation.x = Math.PI / 2;
  dial.position.y = 0.55;
  g.add(dial);

  // Orange Speed Arc
  const arc = new THREE.Mesh(
    new THREE.RingGeometry(0.28, 0.38, 24, 1, 0, Math.PI * 1.3),
    new THREE.MeshBasicMaterial({ color: 0xf97316 })
  );
  arc.position.set(0, 0.55, 0.09);
  g.add(arc);

  // Red Glowing Needle
  const needle = new THREE.Mesh(
    new THREE.ConeGeometry(0.04, 0.34, 4),
    new THREE.MeshBasicMaterial({ color: 0xef4444 })
  );
  needle.rotation.z = -Math.PI * 0.3;
  needle.position.set(0.1, 0.65, 0.1);
  g.add(needle);

  return g;
}

// 4. HIKEPASS: Low-poly Mountain Peak + Floating Teal QR Shield (Teal)
function createHikePassSculpt(): THREE.Group {
  const g = new THREE.Group();
  const mtn = new THREE.Mesh(
    new THREE.ConeGeometry(0.62, 1.05, 5),
    new THREE.MeshToonMaterial({ color: 0x0f766e })
  );
  mtn.position.y = 0.52;
  g.add(mtn);

  const snow = new THREE.Mesh(
    new THREE.ConeGeometry(0.28, 0.45, 5),
    new THREE.MeshToonMaterial({ color: 0xe2e8f0 })
  );
  snow.position.set(0, 0.82, 0);
  g.add(snow);

  const shield = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.35, 0),
    new THREE.MeshPhysicalMaterial({
      color: 0x14b8a6,
      transparent: true,
      opacity: 0.85,
      roughness: 0.1,
    })
  );
  shield.position.set(0, 1.25, 0);
  g.add(shield);

  const qrCore = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.12, 0.12),
    new THREE.MeshBasicMaterial({ color: 0xffffff })
  );
  qrCore.position.set(0, 1.25, 0);
  g.add(qrCore);

  return g;
}

// 5. IDAMAN-TSL: Hexagonal Database Conservation Pillar (Purple/Silver)
function createIdamanTslSculpt(): THREE.Group {
  const g = new THREE.Group();
  const pillar = new THREE.Mesh(
    new THREE.CylinderGeometry(0.48, 0.52, 1.0, 6),
    new THREE.MeshToonMaterial({ color: 0x2e1065 })
  );
  pillar.position.y = 0.55;
  g.add(pillar);

  const diskMat = new THREE.MeshBasicMaterial({ color: 0xa855f7 });
  const silverDiskMat = new THREE.MeshBasicMaterial({ color: 0xd8b4fe });
  [-0.25, 0, 0.25].forEach((yOff, idx) => {
    const disk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.58, 0.58, 0.05, 6),
      idx === 1 ? silverDiskMat : diskMat
    );
    disk.position.set(0, 0.55 + yOff, 0);
    g.add(disk);
  });

  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(0.65, 0.03, 8, 24),
    new THREE.MeshBasicMaterial({ color: 0xc084fc })
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.set(0, 0.55, 0);
  g.add(ring);

  return g;
}

// 6. HIJAUKU: Crystalline Eco Prism + Faceted Emerald Leaf (Green)
function createHijauKuSculpt(): THREE.Group {
  const g = new THREE.Group();
  const prism = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 0.8, 0.8),
    new THREE.MeshPhysicalMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.35,
      roughness: 0.1,
    })
  );
  prism.position.y = 0.55;
  g.add(prism);

  const leafGroup = new THREE.Group();
  const leafMat = new THREE.MeshToonMaterial({ color: 0x22c55e });
  const leafHalf1 = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.55, 3), leafMat);
  leafHalf1.rotation.z = Math.PI * 0.15;
  leafHalf1.position.set(-0.06, 0.55, 0);
  leafGroup.add(leafHalf1);

  const leafHalf2 = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.55, 3), leafMat);
  leafHalf2.rotation.z = -Math.PI * 0.15;
  leafHalf2.position.set(0.06, 0.55, 0);
  leafGroup.add(leafHalf2);
  g.add(leafGroup);

  const orbRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.62, 0.03, 8, 24),
    new THREE.MeshBasicMaterial({ color: 0x4ade80 })
  );
  orbRing.rotation.x = Math.PI * 0.3;
  orbRing.position.set(0, 0.55, 0);
  g.add(orbRing);

  return g;
}

// =========================================================================
// DYNAMIC 2D CANVAS PAINTERS FOR THE 3 VAR MONITORS
// =========================================================================

function drawCenterScreen(ctx: CanvasRenderingContext2D, project: TrophyProject | null, time: number) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  ctx.fillStyle = "#040814";
  ctx.fillRect(0, 0, w, h);

  // Subtle broadcast grid
  ctx.strokeStyle = "rgba(56, 189, 248, 0.08)";
  ctx.lineWidth = 1;
  for (let x = 0; x < w; x += 32) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y < h; y += 32) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  // Broadcast Header Bar
  ctx.fillStyle = "#0a1628";
  ctx.fillRect(0, 0, w, 56);
  ctx.strokeStyle = "rgba(56, 189, 248, 0.35)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 56);
  ctx.lineTo(w, 56);
  ctx.stroke();

  // Blinking REC dot
  const isBlink = Math.sin(time * 6) > 0;
  ctx.fillStyle = isBlink ? "#ef4444" : "#7f1d1d";
  ctx.beginPath();
  ctx.arc(36, 28, 9, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 20px monospace";
  ctx.fillText("VAR FEED 02 // ETIHAD BROADCAST", 58, 35);

  ctx.fillStyle = "#38bdf8";
  ctx.font = "bold 16px monospace";
  ctx.fillText("PLAYMAKER #17 REVIEW", w - 240, 35);

  if (project) {
    // Project Title
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 36px 'Segoe UI', Inter, sans-serif";
    ctx.fillText(project.title, 36, 116);

    // Role & Category
    ctx.fillStyle = "#38bdf8";
    ctx.font = "bold 18px monospace";
    ctx.fillText((project.type + " • " + project.role).toUpperCase(), 36, 150);

    // Key Metric Highlight Box
    ctx.fillStyle = "rgba(16, 185, 129, 0.18)";
    ctx.strokeStyle = "#10b981";
    ctx.lineWidth = 2;
    ctx.fillRect(36, 175, w - 72, 60);
    ctx.strokeRect(36, 175, w - 72, 60);

    ctx.fillStyle = "#34d399";
    ctx.font = "bold 24px monospace";
    ctx.fillText("KEY METRIC: " + project.badgeMetric, 54, 213);

    // Brief Description
    ctx.fillStyle = "#cbd5e1";
    ctx.font = "18px 'Segoe UI', sans-serif";
    const descText = project.description.length > 75 ? project.description.slice(0, 75) + "..." : project.description;
    ctx.fillText(descText, 36, 275);

    // Call to Action Box
    const pulse = Math.sin(time * 5) * 0.15 + 0.85;
    ctx.fillStyle = `rgba(56, 189, 248, ${0.28 * pulse})`;
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 3;
    ctx.fillRect(36, 315, w - 72, 75);
    ctx.strokeRect(36, 315, w - 72, 75);

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 24px monospace";
    ctx.fillText("⚡ INSPECT VAR CASE STUDY [CLICK / ENTER]", 60, 362);
  } else {
    // Default Idle
    ctx.fillStyle = "#38bdf8";
    ctx.font = "bold 32px monospace";
    ctx.fillText("ETIHAD VAR CONTROL ROOM", 36, 125);

    ctx.fillStyle = "#94a3b8";
    ctx.font = "20px monospace";
    ctx.fillText("6 PRODUCTION SYSTEM NODES ONLINE // ZERO CRITICAL DEFECTS", 36, 170);

    // Glowing wave line
    ctx.strokeStyle = "#00e5ff";
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let x = 36; x < w - 36; x += 8) {
      const y = 250 + Math.sin(x * 0.02 + time * 4) * 35;
      if (x === 36) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    ctx.fillStyle = "#64748b";
    ctx.font = "bold 18px monospace";
    ctx.fillText("APPROACH PEDESTAL TO ACTIVATE REALTIME PROJECT TELEMETRY", 36, 340);
  }
}

function drawLeftScreen(ctx: CanvasRenderingContext2D, project: TrophyProject | null) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  ctx.fillStyle = "#040814";
  ctx.fillRect(0, 0, w, h);

  // Header
  ctx.fillStyle = "#0a1628";
  ctx.fillRect(0, 0, w, 44);
  ctx.strokeStyle = "rgba(56, 189, 248, 0.35)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 44);
  ctx.lineTo(w, 44);
  ctx.stroke();

  ctx.fillStyle = "#38bdf8";
  ctx.font = "bold 16px monospace";
  ctx.fillText("TECH STACK ARCHITECTURE RADAR", 24, 28);

  if (project) {
    const nodes = [
      { step: "EDGE / CLIENT", val: project.tacticalArchitecture.frontend.split(",")[0].trim() },
      { step: "SERVICES", val: project.tacticalArchitecture.backend.split(",")[0].trim() },
      { step: "DATA PIPELINE", val: project.tacticalArchitecture.dataPipeline.split(" ")[0].trim() + " DB" },
    ];

    let startY = 70;
    nodes.forEach((n, idx) => {
      ctx.fillStyle = "rgba(10, 22, 40, 0.8)";
      ctx.strokeStyle = idx === 0 ? "#00e5ff" : idx === 1 ? "#f59e0b" : "#a855f7";
      ctx.lineWidth = 1.5;
      ctx.fillRect(24, startY, w - 48, 48);
      ctx.strokeRect(24, startY, w - 48, 48);

      ctx.fillStyle = "#94a3b8";
      ctx.font = "12px monospace";
      ctx.fillText(n.step, 36, startY + 20);

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 15px monospace";
      ctx.fillText(n.val.slice(0, 28), 36, startY + 40);

      startY += 58;
    });

    ctx.fillStyle = "#38bdf8";
    ctx.font = "13px monospace";
    ctx.fillText("TAGS: " + project.tags.slice(0, 4).join(" • "), 24, startY + 20);
  } else {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "16px monospace";
    ctx.fillText("DISTRIBUTED STACK MATRIX", 24, 85);

    const stacks = [
      "FLUTTER • CLEAN ARCHITECTURE",
      "NEXT.JS 14/15 • TURBOPACK",
      "NESTJS • MODULAR MICROSERVICES",
      "POSTGRESQL • PRISMA • RLS",
      "ESP32 EDGE • MQTT / TELEMETRY",
    ];
    stacks.forEach((st, idx) => {
      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 14px monospace";
      ctx.fillText("▶ " + st, 24, 125 + idx * 30);
    });
  }
}

function drawRightScreen(ctx: CanvasRenderingContext2D, project: TrophyProject | null) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  ctx.fillStyle = "#040814";
  ctx.fillRect(0, 0, w, h);

  // Header
  ctx.fillStyle = "#0a1628";
  ctx.fillRect(0, 0, w, 44);
  ctx.strokeStyle = "rgba(56, 189, 248, 0.35)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 44);
  ctx.lineTo(w, 44);
  ctx.stroke();

  ctx.fillStyle = "#f59e0b";
  ctx.font = "bold 16px monospace";
  ctx.fillText("KEY MATCH TELEMETRY & STATS", 24, 28);

  const bars = project
    ? [
        { label: "THROUGHPUT / SPEED", val: 96, color: "#00e5ff" },
        { label: "RELIABILITY & STABILITY", val: 99, color: "#10b981" },
        { label: "CODE AUDIT & ACCURACY", val: 100, color: "#f59e0b" },
      ]
    : [
        { label: "SYSTEM RENDERING FPS", val: 100, color: "#00e5ff" },
        { label: "CLOUD AVAILABILITY", val: 99, color: "#10b981" },
        { label: "TEST SUITE COVERAGE", val: 95, color: "#f59e0b" },
      ];

  let startY = 70;
  bars.forEach((b) => {
    ctx.fillStyle = "#cbd5e1";
    ctx.font = "bold 13px monospace";
    ctx.fillText(`${b.label} — ${b.val}%`, 24, startY + 14);

    ctx.fillStyle = "#0a1220";
    ctx.fillRect(24, startY + 22, w - 48, 16);

    ctx.fillStyle = b.color;
    ctx.fillRect(24, startY + 22, ((w - 48) * b.val) / 100, 16);

    startY += 52;
  });

  if (project && project.metrics.length > 0) {
    ctx.fillStyle = "rgba(56, 189, 248, 0.15)";
    ctx.fillRect(24, startY + 8, w - 48, 45);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 14px monospace";
    ctx.fillText(`${project.metrics[0].label}: ${project.metrics[0].value}`, 36, startY + 36);
  }
}

export function buildEtihadDiorama(scene: THREE.Scene): DioramaInteractiveObjects {
  const dioramaGroup = new THREE.Group();
  dioramaGroup.name = "etihad-diorama";

  // Reusable Stylized Materials
  const woodLockerFloorMat = new THREE.MeshToonMaterial({ color: 0x3d271d });
  const wallMat = new THREE.MeshToonMaterial({ color: 0x0f172a });
  const cutawayBorderMat = new THREE.MeshBasicMaterial({ color: 0x6cabdd });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x98c5e9,
    transparent: true,
    opacity: 0.35,
    roughness: 0.1,
    transmission: 0.8,
    thickness: 0.5,
  });
  const grassMat = new THREE.MeshToonMaterial({ color: 0x1e7e34 });
  const grassStripeMat = new THREE.MeshToonMaterial({ color: 0x24913c });
  const pitchLineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

  // Master Diorama Base Slab
  const baseGeo = new THREE.BoxGeometry(58, 1.2, 16);
  const baseMesh = new THREE.Mesh(baseGeo, new THREE.MeshToonMaterial({ color: 0x070c14 }));
  baseMesh.position.set(2, -0.6, 0);
  dioramaGroup.add(baseMesh);

  // Cutaway Base Highlight Edge
  const edgeGeo = new THREE.BoxGeometry(58.2, 0.1, 0.1);
  const frontEdge = new THREE.Mesh(edgeGeo, cutawayBorderMat);
  frontEdge.position.set(2, 0.05, 8);
  dioramaGroup.add(frontEdge);

  const interactiveObjects: DioramaInteractiveObjects = {
    lockers: [],
    trophies: [],
    milestones: [],
    jumbotron: { mesh: new THREE.Object3D(), position: [26, 6, -6] },
    kickoffBallTarget: { mesh: new THREE.Object3D(), position: [18, 0.25, 0] },
  };

  // =========================================================================
  // ZONE 1: THE DRESSING ROOM (X: -25 to -15)
  // Circular Etihad locker room, wooden benches, sky blue glowing lockers
  // =========================================================================
  const zone1Group = new THREE.Group();
  zone1Group.position.set(-20, 0, 0);

  // Floor
  const drFloorGeo = new THREE.CylinderGeometry(6.5, 6.5, 0.2, 32);
  const drFloor = new THREE.Mesh(drFloorGeo, woodLockerFloorMat);
  drFloor.position.set(0, 0.1, 0);
  zone1Group.add(drFloor);

  // Central Manchester City crest / Circle floor logo
  const crestGeo = new THREE.RingGeometry(0.8, 2.4, 32);
  const crestMat = new THREE.MeshBasicMaterial({ color: 0x6cabdd, side: THREE.DoubleSide });
  const crest = new THREE.Mesh(crestGeo, crestMat);
  crest.rotation.x = -Math.PI / 2;
  crest.position.set(0, 0.21, 0);
  zone1Group.add(crest);

  // Back semi-circular curved wall
  const wallRadius = 6.2;
  const wallArc = Math.PI * 1.1;
  const wallGeo = new THREE.CylinderGeometry(wallRadius, wallRadius, 4.5, 32, 1, true, Math.PI * 0.45, wallArc);
  const drWall = new THREE.Mesh(wallGeo, wallMat);
  drWall.position.set(0, 2.25, 0);
  zone1Group.add(drWall);

  // Circular curved bench
  const benchGeo = new THREE.TorusGeometry(5.0, 0.4, 8, 24, Math.PI);
  const benchMat = new THREE.MeshToonMaterial({ color: 0x5a3825 });
  const bench = new THREE.Mesh(benchGeo, benchMat);
  bench.rotation.x = Math.PI / 2;
  bench.rotation.z = Math.PI * 0.5;
  bench.position.set(0, 0.45, -0.6);
  zone1Group.add(bench);

  // 3 Interactive Lockers (#17 Tiki-Taka, #8 Engine, #10 Visionary)
  const lockerPositions: { id: "tiki-taka" | "engine" | "visionary"; num: string; pos: [number, number, number]; rotY: number; color: number }[] = [
    { id: "tiki-taka", num: "17", pos: [-3.6, 2.1, -3.2], rotY: 0.6, color: 0x00e5ff },
    { id: "engine", num: "8", pos: [0, 2.1, -4.8], rotY: 0, color: 0x6cabdd },
    { id: "visionary", num: "10", pos: [3.6, 2.1, -3.2], rotY: -0.6, color: 0xffd700 },
  ];

  lockerPositions.forEach(({ id, pos, rotY, color }) => {
    const lockerUnit = new THREE.Group();
    lockerUnit.position.set(...pos);
    lockerUnit.rotation.y = rotY;

    // Outer Locker Wardrobe
    const frameGeo = new THREE.BoxGeometry(2.0, 3.8, 1.2);
    const frameMat = new THREE.MeshToonMaterial({ color: 0x162032 });
    const lockerFrame = new THREE.Mesh(frameGeo, frameMat);
    lockerUnit.add(lockerFrame);

    // Neon Frame Accent
    const neonGeo = new THREE.BoxGeometry(2.05, 0.08, 1.25);
    const neonMat = new THREE.MeshBasicMaterial({ color });
    const topNeon = new THREE.Mesh(neonGeo, neonMat);
    topNeon.position.y = 1.88;
    lockerUnit.add(topNeon);

    // Hanging Jersey #17 / #8 / #10 inside
    const jerseyGeo = new THREE.BoxGeometry(1.0, 1.4, 0.25);
    const jerseyMat = new THREE.MeshToonMaterial({ color });
    const jersey = new THREE.Mesh(jerseyGeo, jerseyMat);
    jersey.position.set(0, 0.4, 0.15);
    lockerUnit.add(jersey);

    // Floating Interactive Indicator Ring above locker
    const ringGeo = new THREE.TorusGeometry(0.55, 0.07, 8, 24);
    const ringMat = new THREE.MeshBasicMaterial({ color });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, 2.4, 0);
    ring.name = `indicator-locker-${id}`;
    lockerUnit.add(ring);

    // Number plate badge
    const badgeGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.08, 16);
    const badgeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const badge = new THREE.Mesh(badgeGeo, badgeMat);
    badge.rotation.x = Math.PI / 2;
    badge.position.set(0, 1.4, 0.61);
    lockerUnit.add(badge);

    lockerUnit.name = `locker-${id}`;
    zone1Group.add(lockerUnit);

    // Register interactive target coordinates
    const worldX = -20 + pos[0];
    const worldY = pos[1];
    const worldZ = pos[2];
    interactiveObjects.lockers.push({
      id,
      mesh: lockerUnit,
      position: [worldX, worldY, worldZ],
    });
  });

  dioramaGroup.add(zone1Group);

  // =========================================================================
  // ZONE 2: TROPHY & VAR CONTROL ROOM (X: -14 to -2)
  // 6 Bespoke Voxel/Tactical 3D Miniatures & Multi-Monitor VAR Workstation
  // =========================================================================
  const zone2Group = new THREE.Group();
  zone2Group.position.set(-8, 0, 0);

  // Floor: Dark matte reflect with tactical pitch markings
  const varFloorGeo = new THREE.BoxGeometry(12, 0.2, 14);
  const varFloorMat = new THREE.MeshToonMaterial({ color: 0x070d18 });
  const varFloor = new THREE.Mesh(varFloorGeo, varFloorMat);
  varFloor.position.set(0, 0.1, 0);
  zone2Group.add(varFloor);

  // Tactical grid pattern lines on VAR floor
  const gridHelper = new THREE.GridHelper(11, 8, 0x38bdf8, 0x111e33);
  gridHelper.position.set(0, 0.22, 0);
  zone2Group.add(gridHelper);

  // Tactical Glowing Floor Markings (Box penalty arc for Zone 2)
  const zoneBoxGeo = new THREE.RingGeometry(4.2, 4.3, 32);
  const zoneBoxMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, side: THREE.DoubleSide });
  const zoneCircle = new THREE.Mesh(zoneBoxGeo, zoneBoxMat);
  zoneCircle.rotation.x = -Math.PI / 2;
  zoneCircle.position.set(0, 0.23, 0.5);
  zone2Group.add(zoneCircle);

  // Back Wall with VAR monitors
  const varWallGeo = new THREE.BoxGeometry(12, 4.8, 0.5);
  const varWall = new THREE.Mesh(varWallGeo, wallMat);
  varWall.position.set(0, 2.4, -6.8);
  zone2Group.add(varWall);

  // Dynamic Multi-Monitor VAR Control Setup (HTML5 Canvas Textures)
  const centerCanvas = document.createElement("canvas");
  centerCanvas.width = 1024;
  centerCanvas.height = 512;
  const centerCtx = centerCanvas.getContext("2d");
  const centerTex = new THREE.CanvasTexture(centerCanvas);

  const leftCanvas = document.createElement("canvas");
  leftCanvas.width = 512;
  leftCanvas.height = 384;
  const leftCtx = leftCanvas.getContext("2d");
  const leftTex = new THREE.CanvasTexture(leftCanvas);

  const rightCanvas = document.createElement("canvas");
  rightCanvas.width = 512;
  rightCanvas.height = 384;
  const rightCtx = rightCanvas.getContext("2d");
  const rightTex = new THREE.CanvasTexture(rightCanvas);

  // Draw initial state on screens
  if (centerCtx) drawCenterScreen(centerCtx, null, 0);
  if (leftCtx) drawLeftScreen(leftCtx, null);
  if (rightCtx) drawRightScreen(rightCtx, null);
  centerTex.needsUpdate = true;
  leftTex.needsUpdate = true;
  rightTex.needsUpdate = true;

  // Screen frames & meshes
  const monitorMeshes = [
    { x: -3.8, y: 3.2, w: 2.8, h: 1.6, tex: leftTex },
    { x: 0, y: 3.4, w: 3.8, h: 2.0, tex: centerTex },
    { x: 3.8, y: 3.2, w: 2.8, h: 1.6, tex: rightTex },
  ];

  monitorMeshes.forEach(({ x, y, w, h, tex }) => {
    const screenFrameGeo = new THREE.BoxGeometry(w + 0.15, h + 0.15, 0.2);
    const screenFrame = new THREE.Mesh(screenFrameGeo, new THREE.MeshBasicMaterial({ color: 0x050911 }));
    screenFrame.position.set(x, y, -6.5);
    zone2Group.add(screenFrame);

    const screenSurfaceGeo = new THREE.PlaneGeometry(w, h);
    const screenMat = new THREE.MeshBasicMaterial({ map: tex });
    const screen = new THREE.Mesh(screenSurfaceGeo, screenMat);
    screen.position.set(x, y, -6.38);
    zone2Group.add(screen);
  });

  // VAR Desk
  const deskGeo = new THREE.BoxGeometry(9, 1.1, 1.6);
  const desk = new THREE.Mesh(deskGeo, new THREE.MeshToonMaterial({ color: 0x111c2e }));
  desk.position.set(0, 0.55, -5.2);
  zone2Group.add(desk);

  // 6 Bespoke Project Sculptures
  const trophyConfigs: {
    id: string;
    x: number;
    z: number;
    builder: () => THREE.Group;
    glowColor: number;
  }[] = [
    { id: "futsalpro", x: -4.2, z: -1.6, builder: createFutsalProSculpt, glowColor: 0x10b981 },
    { id: "smart-kandang", x: 0, z: -1.6, builder: createSmartKandangSculpt, glowColor: 0x00e5ff },
    { id: "rideassist", x: 4.2, z: -1.6, builder: createRideAssistSculpt, glowColor: 0xf97316 },
    { id: "hikepass-mobile", x: -4.2, z: 2.6, builder: createHikePassSculpt, glowColor: 0x14b8a6 },
    { id: "idaman-tsl", x: 0, z: 2.6, builder: createIdamanTslSculpt, glowColor: 0xa855f7 },
    { id: "bank-sampah", x: 4.2, z: 2.6, builder: createHijauKuSculpt, glowColor: 0x22c55e },
  ];

  trophyConfigs.forEach(({ id, x, z, builder, glowColor }) => {
    const trophyUnit = new THREE.Group();
    trophyUnit.position.set(x, 0, z);

    // Floor Contact Shadow disk under each pedestal
    const shadowGeo = new THREE.CircleGeometry(0.9, 16);
    const shadowMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.6 });
    const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.y = 0.225;
    trophyUnit.add(contactShadow);

    // Glass pedestal cylinder
    const pedestalGeo = new THREE.CylinderGeometry(0.68, 0.78, 1.2, 16);
    const pedestal = new THREE.Mesh(pedestalGeo, glassMat);
    pedestal.position.y = 0.6;
    trophyUnit.add(pedestal);

    // Glowing Neon Base Ring
    const pedBaseGeo = new THREE.CylinderGeometry(0.82, 0.88, 0.14, 16);
    const pedBase = new THREE.Mesh(pedBaseGeo, new THREE.MeshBasicMaterial({ color: glowColor }));
    pedBase.position.y = 0.08;
    trophyUnit.add(pedBase);

    // Custom 3D Sculpture Group
    const trophySculpt = builder();
    trophySculpt.position.y = 1.2;
    trophySculpt.name = `trophy-sculpt-${id}`;
    trophyUnit.add(trophySculpt);

    // Interactive Floating Halo Indicator
    const ringGeo = new THREE.TorusGeometry(0.48, 0.045, 8, 20);
    const ringMat = new THREE.MeshBasicMaterial({ color: glowColor });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, 2.4, 0);
    ring.name = `indicator-trophy-${id}`;
    trophyUnit.add(ring);

    trophyUnit.name = `trophy-${id}`;
    zone2Group.add(trophyUnit);

    const worldX = -8 + x;
    const worldY = 1.6;
    const worldZ = z;
    interactiveObjects.trophies.push({
      id,
      mesh: trophyUnit,
      position: [worldX, worldY, worldZ],
    });
  });

  // VAR screens dynamic updater callback
  let lastProjectTitle = "";
  interactiveObjects.updateVarScreens = (project, time) => {
    if (centerCtx && leftCtx && rightCtx) {
      const title = project?.title || "";
      // Only re-draw left & right screens on project change to save GPU cycles
      if (title !== lastProjectTitle) {
        lastProjectTitle = title;
        drawLeftScreen(leftCtx, project);
        drawRightScreen(rightCtx, project);
        leftTex.needsUpdate = true;
        rightTex.needsUpdate = true;
      }
      // Re-draw center screen for pulsating animations
      drawCenterScreen(centerCtx, project, time);
      centerTex.needsUpdate = true;
    }
  };

  dioramaGroup.add(zone2Group);

  // =========================================================================
  // ZONE 3: THE GLASS TUNNEL (X: -2 to 10)
  // Transparent architectural glass tunnel leading toward the stadium pitch
  // =========================================================================
  const zone3Group = new THREE.Group();
  zone3Group.position.set(4, 0, 0);

  // Tunnel Floor
  const tunnelFloorGeo = new THREE.BoxGeometry(12, 0.2, 8);
  const tunnelFloor = new THREE.Mesh(tunnelFloorGeo, new THREE.MeshToonMaterial({ color: 0x111622 }));
  tunnelFloor.position.set(0, 0.1, 0);
  zone3Group.add(tunnelFloor);

  // Tunnel Central Blue Carpet Runway
  const runwayGeo = new THREE.BoxGeometry(12, 0.02, 2.6);
  const runwayMat = new THREE.MeshToonMaterial({ color: 0x00285e });
  const runway = new THREE.Mesh(runwayGeo, runwayMat);
  runway.position.set(0, 0.22, 0);
  zone3Group.add(runway);

  // Glass Arches
  for (let i = -5; i <= 5; i += 2.5) {
    const archGroup = new THREE.Group();
    archGroup.position.set(i, 0, 0);

    // Steel Rib Outer Frame
    const ribGeo = new THREE.TorusGeometry(3.6, 0.14, 8, 24, Math.PI);
    const ribMat = new THREE.MeshToonMaterial({ color: 0x3d4b64 });
    const rib = new THREE.Mesh(ribGeo, ribMat);
    rib.rotation.z = Math.PI;
    rib.rotation.y = Math.PI / 2;
    rib.position.set(0, 0.2, 0);
    archGroup.add(rib);

    // Glass Panel Shell
    const glassShellGeo = new THREE.CylinderGeometry(3.5, 3.5, 2.2, 16, 1, true, 0, Math.PI);
    const glassShell = new THREE.Mesh(glassShellGeo, glassMat);
    glassShell.rotation.z = Math.PI / 2;
    glassShell.rotation.x = Math.PI;
    glassShell.position.set(0, 0.2, 0);
    archGroup.add(glassShell);

    zone3Group.add(archGroup);
  }

  // 3 Hologram Milestones along the tunnel
  const milestoneConfigs = [
    { id: "coe-telkom", x: -3.5, z: -2.8, color: 0x00e5ff },
    { id: "asisten-lab", x: 0, z: 2.8, color: 0xffd700 },
    { id: "pendidikan-formal", x: 3.5, z: -2.8, color: 0x6cabdd },
  ];

  milestoneConfigs.forEach(({ id, x, z, color }) => {
    const msGroup = new THREE.Group();
    msGroup.position.set(x, 0, z);

    // Hologram Pylon Base
    const pylonGeo = new THREE.CylinderGeometry(0.35, 0.45, 0.8, 16);
    const pylon = new THREE.Mesh(pylonGeo, new THREE.MeshToonMaterial({ color: 0x1f2937 }));
    pylon.position.y = 0.4;
    msGroup.add(pylon);

    // Floating Hologram Panel (translucent glowing pane)
    const paneGeo = new THREE.BoxGeometry(1.6, 1.8, 0.05);
    const paneMat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.65 });
    const pane = new THREE.Mesh(paneGeo, paneMat);
    pane.position.set(0, 1.8, 0);
    pane.rotation.y = z < 0 ? 0.35 : -0.35;
    msGroup.add(pane);

    // Hologram Indicator Ring
    const ringGeo = new THREE.TorusGeometry(0.4, 0.04, 6, 16);
    const ringMat = new THREE.MeshBasicMaterial({ color });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, 2.9, 0);
    ring.name = `indicator-milestone-${id}`;
    msGroup.add(ring);

    msGroup.name = `milestone-${id}`;
    zone3Group.add(msGroup);

    const worldX = 4 + x;
    const worldY = 1.8;
    const worldZ = z;
    interactiveObjects.milestones.push({
      id,
      mesh: msGroup,
      position: [worldX, worldY, worldZ],
    });
  });

  dioramaGroup.add(zone3Group);

  // =========================================================================
  // ZONE 4: THE PITCH & JUMBOTRON (X: 10 to 30)
  // Striped soccer turf, center circle with "Kick-Off Project" ball,
  // stadium floodlight masts, and giant Jumbotron scoreboard
  // =========================================================================
  const zone4Group = new THREE.Group();
  zone4Group.position.set(20, 0, 0);

  // Striped Grass Pitch (alternating mown grass bands)
  const pitchWidth = 20;
  const pitchDepth = 15;
  const stripeWidth = 2.5;
  for (let x = -pitchWidth / 2; x < pitchWidth / 2; x += stripeWidth) {
    const isEven = Math.round((x + pitchWidth / 2) / stripeWidth) % 2 === 0;
    const stripeGeo = new THREE.BoxGeometry(stripeWidth, 0.2, pitchDepth);
    const stripe = new THREE.Mesh(stripeGeo, isEven ? grassMat : grassStripeMat);
    stripe.position.set(x + stripeWidth / 2, 0.1, 0);
    zone4Group.add(stripe);
  }

  // Pitch White Markings:
  // 1. Center Line
  const centerLineGeo = new THREE.PlaneGeometry(0.14, pitchDepth - 1);
  const centerLine = new THREE.Mesh(centerLineGeo, pitchLineMat);
  centerLine.rotation.x = -Math.PI / 2;
  centerLine.position.set(-2, 0.22, 0);
  zone4Group.add(centerLine);

  // 2. Center Circle
  const centerCircleGeo = new THREE.RingGeometry(3.4, 3.55, 36);
  const centerCircle = new THREE.Mesh(centerCircleGeo, pitchLineMat);
  centerCircle.rotation.x = -Math.PI / 2;
  centerCircle.position.set(-2, 0.23, 0);
  zone4Group.add(centerCircle);

  // 3. Center Spot
  const centerSpotGeo = new THREE.CircleGeometry(0.35, 16);
  const centerSpot = new THREE.Mesh(centerSpotGeo, pitchLineMat);
  centerSpot.rotation.x = -Math.PI / 2;
  centerSpot.position.set(-2, 0.24, 0);
  zone4Group.add(centerSpot);

  // Goal Structure on the right end
  const goalGroup = new THREE.Group();
  goalGroup.position.set(9.2, 0, 0);
  const postMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

  const leftPost = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.6, 8), postMat);
  leftPost.position.set(0, 1.3, -2.4);
  goalGroup.add(leftPost);

  const rightPost = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.6, 8), postMat);
  rightPost.position.set(0, 1.3, 2.4);
  goalGroup.add(rightPost);

  const crossbar = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 4.88, 8), postMat);
  crossbar.rotation.x = Math.PI / 2;
  crossbar.position.set(0, 2.6, 0);
  goalGroup.add(crossbar);

  // Goal Net Mesh
  const netMat = new THREE.MeshBasicMaterial({ color: 0x98c5e9, wireframe: true, transparent: true, opacity: 0.4 });
  const netGeo = new THREE.BoxGeometry(1.6, 2.5, 4.8);
  const net = new THREE.Mesh(netGeo, netMat);
  net.position.set(0.8, 1.25, 0);
  goalGroup.add(net);
  zone4Group.add(goalGroup);

  // Stadium Stands Cutaway Background
  const standsGeo = new THREE.BoxGeometry(22, 5.0, 3.0);
  const standsMat = new THREE.MeshToonMaterial({ color: 0x00285e });
  const stands = new THREE.Mesh(standsGeo, standsMat);
  stands.position.set(0, 2.5, -7.5);
  zone4Group.add(stands);

  // Giant Jumbotron Screen
  const jumbotronGroup = new THREE.Group();
  jumbotronGroup.position.set(0, 7.2, -6.8);

  // Pylon Stems
  const pylonMat = new THREE.MeshToonMaterial({ color: 0x22354d });
  const leftStem = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4.5, 0.4), pylonMat);
  leftStem.position.set(-4, -2.2, 0);
  jumbotronGroup.add(leftStem);

  const rightStem = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4.5, 0.4), pylonMat);
  rightStem.position.set(4, -2.2, 0);
  jumbotronGroup.add(rightStem);

  // Frame
  const jumbotronFrame = new THREE.Mesh(new THREE.BoxGeometry(10.2, 4.2, 0.6), new THREE.MeshBasicMaterial({ color: 0x070c14 }));
  jumbotronGroup.add(jumbotronFrame);

  // Digital Jumbotron Screen
  const jumbotronScreenGeo = new THREE.PlaneGeometry(9.6, 3.6);
  const jumbotronScreenMat = new THREE.MeshBasicMaterial({ color: 0x00285e });
  const jumbotronScreen = new THREE.Mesh(jumbotronScreenGeo, jumbotronScreenMat);
  jumbotronScreen.position.z = 0.32;
  jumbotronGroup.add(jumbotronScreen);

  // Jumbotron Pulsing Neon Header Line
  const jumbotronNeon = new THREE.Mesh(new THREE.BoxGeometry(9.8, 0.12, 0.2), new THREE.MeshBasicMaterial({ color: 0x00e5ff }));
  jumbotronNeon.position.set(0, 1.95, 0.3);
  jumbotronGroup.add(jumbotronNeon);

  jumbotronGroup.name = "jumbotron";
  zone4Group.add(jumbotronGroup);

  // Register interactive jumbotron
  interactiveObjects.jumbotron = {
    mesh: jumbotronGroup,
    position: [20, 7.2, -6.5],
  };

  // Kick-Off Ball Spot (Center Circle Spot)
  interactiveObjects.kickoffBallTarget = {
    mesh: centerSpot,
    position: [18, 0.25, 0],
  };

  dioramaGroup.add(zone4Group);

  scene.add(dioramaGroup);
  return interactiveObjects;
}
