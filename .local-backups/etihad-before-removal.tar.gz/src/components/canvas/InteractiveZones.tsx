import * as THREE from "three";
import type { DioramaInteractiveObjects } from "./EtihadDiorama";

export interface RaycastHitResult {
  targetType: "locker" | "trophy" | "milestone" | "jumbotron" | "floor" | null;
  targetId: string | null;
  targetPosition: THREE.Vector3;
}

export class InteractiveZoneManager {
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  private interactiveObjects: DioramaInteractiveObjects;
  private clickableMeshes: { mesh: THREE.Object3D; type: RaycastHitResult["targetType"]; id: string | null; pos: [number, number, number] }[] = [];
  private floorMesh: THREE.Mesh | null = null;
  private animTime = 0;

  constructor(scene: THREE.Scene, objects: DioramaInteractiveObjects) {
    this.interactiveObjects = objects;

    // Collect clickable objects
    objects.lockers.forEach((l) => {
      this.clickableMeshes.push({ mesh: l.mesh, type: "locker", id: l.id, pos: l.position });
    });

    objects.trophies.forEach((t) => {
      this.clickableMeshes.push({ mesh: t.mesh, type: "trophy", id: t.id, pos: t.position });
    });

    objects.milestones.forEach((m) => {
      this.clickableMeshes.push({ mesh: m.mesh, type: "milestone", id: m.id, pos: m.position });
    });

    this.clickableMeshes.push({
      mesh: objects.jumbotron.mesh,
      type: "jumbotron",
      id: "jumbotron",
      pos: objects.jumbotron.position,
    });

    this.clickableMeshes.push({
      mesh: objects.kickoffBallTarget.mesh,
      type: "jumbotron",
      id: "kickoff",
      pos: [20, 7.2, -6.5],
    });

    // Create an invisible ground plane for point-and-click floor targeting
    const floorGeo = new THREE.PlaneGeometry(70, 24);
    const floorMat = new THREE.MeshBasicMaterial({ visible: false });
    this.floorMesh = new THREE.Mesh(floorGeo, floorMat);
    this.floorMesh.rotation.x = -Math.PI / 2;
    this.floorMesh.position.y = 0.05;
    scene.add(this.floorMesh);
  }

  public update(deltaTime: number) {
    this.animTime += deltaTime;
    const bob = Math.sin(this.animTime * 3) * 0.12;

    // Animate subtle bobbing on indicators
    this.interactiveObjects.lockers.forEach((l) => {
      const ring = l.mesh.getObjectByName(`indicator-locker-${l.id}`);
      if (ring) {
        ring.position.y = 2.4 + bob;
        ring.rotation.z += deltaTime * 1.5;
      }
    });

    this.interactiveObjects.trophies.forEach((t) => {
      const ring = t.mesh.getObjectByName(`indicator-trophy-${t.id}`);
      const sculpt = t.mesh.getObjectByName(`trophy-sculpt-${t.id}`);
      if (ring) {
        ring.position.y = 2.3 + bob;
        ring.rotation.z += deltaTime * 1.5;
      }
      if (sculpt) {
        sculpt.rotation.y += deltaTime * 0.8;
      }
    });

    this.interactiveObjects.milestones.forEach((m) => {
      const ring = m.mesh.getObjectByName(`indicator-milestone-${m.id}`);
      if (ring) {
        ring.position.y = 2.9 + bob;
        ring.rotation.z += deltaTime * 1.5;
      }
    });
  }

  public testRaycast(
    clientX: number,
    clientY: number,
    containerWidth: number,
    containerHeight: number,
    camera: THREE.Camera
  ): RaycastHitResult {
    this.mouse.x = (clientX / containerWidth) * 2 - 1;
    this.mouse.y = -(clientY / containerHeight) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, camera);

    // 1. Check interactive items first (highest priority)
    for (const item of this.clickableMeshes) {
      const intersects = this.raycaster.intersectObject(item.mesh, true);
      if (intersects.length > 0) {
        return {
          targetType: item.type,
          targetId: item.id,
          targetPosition: new THREE.Vector3(...item.pos),
        };
      }
    }

    // 2. Check floor plane for character movement
    if (this.floorMesh) {
      const floorIntersects = this.raycaster.intersectObject(this.floorMesh, false);
      if (floorIntersects.length > 0) {
        return {
          targetType: "floor",
          targetId: null,
          targetPosition: floorIntersects[0].point,
        };
      }
    }

    return {
      targetType: null,
      targetId: null,
      targetPosition: new THREE.Vector3(0, 0, 0),
    };
  }
}
