import * as THREE from "three";

/**
 * Stylized Cartoon Footballer (#17 - Fauzan) and Soccer Ball
 * Handles keyboard WASD, click-to-move, walk animation cycle, and boundary constraints.
 */

export class PlayerController {
  public playerGroup: THREE.Group;
  public ballMesh: THREE.Mesh;
  public ballShadow: THREE.Mesh;

  // Character body parts for walk animation
  private leftLeg: THREE.Mesh;
  private rightLeg: THREE.Mesh;
  private leftArm: THREE.Mesh;
  private rightArm: THREE.Mesh;
  private torso: THREE.Mesh;
  private head: THREE.Group;

  // Movement physics & state
  public position: THREE.Vector3 = new THREE.Vector3(18, 0, 0);
  public velocity: THREE.Vector3 = new THREE.Vector3(0, 0, 0);
  public moveTarget: THREE.Vector3 | null = null;
  public currentHeading = -Math.PI / 2; // Facing left initially towards diorama
  public isMoving = false;
  private walkCycleTime = 0;

  // Input states
  private keys: { [key: string]: boolean } = {};
  public joystickVector = { x: 0, y: 0 };

  constructor(scene: THREE.Scene) {
    this.playerGroup = new THREE.Group();
    this.playerGroup.name = "player-fauzan-17";
    this.playerGroup.position.copy(this.position);

    // ==========================================
    // Stylized Cel-Shaded Materials
    // ==========================================
    const jerseyMat = new THREE.MeshToonMaterial({ color: 0x6cabdd }); // Etihad Sky Blue
    const whiteMat = new THREE.MeshToonMaterial({ color: 0xffffff });  // Shorts & trims
    const skinMat = new THREE.MeshToonMaterial({ color: 0xd4a373 });   // Natural skin
    const hairMat = new THREE.MeshToonMaterial({ color: 0x1f1917 });   // Dark hair
    const bootMat = new THREE.MeshToonMaterial({ color: 0x111622 });   // Cleats
    const goldMat = new THREE.MeshBasicMaterial({ color: 0xffd700 });  // #17 badge & captain band
    const ballMat = new THREE.MeshToonMaterial({ color: 0xf5f7fb });

    // 1. Torso & Jersey #17
    const torsoGeo = new THREE.BoxGeometry(0.85, 1.1, 0.48);
    this.torso = new THREE.Mesh(torsoGeo, jerseyMat);
    this.torso.position.y = 1.35;
    this.playerGroup.add(this.torso);

    // Back Number 17 Plate
    const numPlateGeo = new THREE.PlaneGeometry(0.42, 0.42);
    const numPlate = new THREE.Mesh(numPlateGeo, goldMat);
    numPlate.position.set(0, 1.45, -0.25);
    numPlate.rotation.y = Math.PI;
    this.playerGroup.add(numPlate);

    // White V-Neck Collar
    const collarGeo = new THREE.BoxGeometry(0.4, 0.12, 0.49);
    const collar = new THREE.Mesh(collarGeo, whiteMat);
    collar.position.set(0, 1.88, 0);
    this.playerGroup.add(collar);

    // 2. Head & Hair
    this.head = new THREE.Group();
    this.head.position.y = 2.15;

    const headGeo = new THREE.BoxGeometry(0.55, 0.58, 0.55);
    const headMesh = new THREE.Mesh(headGeo, skinMat);
    this.head.add(headMesh);

    const hairGeo = new THREE.BoxGeometry(0.58, 0.28, 0.58);
    const hairMesh = new THREE.Mesh(hairGeo, hairMat);
    hairMesh.position.y = 0.24;
    this.head.add(hairMesh);

    this.playerGroup.add(this.head);

    // 3. Arms
    const armGeo = new THREE.BoxGeometry(0.24, 0.85, 0.24);

    this.leftArm = new THREE.Mesh(armGeo, jerseyMat);
    this.leftArm.position.set(-0.58, 1.32, 0);
    this.playerGroup.add(this.leftArm);

    this.rightArm = new THREE.Mesh(armGeo, jerseyMat);
    this.rightArm.position.set(0.58, 1.32, 0);
    this.playerGroup.add(this.rightArm);

    // Captain Band on Left Arm
    const bandGeo = new THREE.BoxGeometry(0.26, 0.14, 0.26);
    const captainBand = new THREE.Mesh(bandGeo, goldMat);
    captainBand.position.y = 0.1;
    this.leftArm.add(captainBand);

    // 4. Shorts & Legs
    const shortsGeo = new THREE.BoxGeometry(0.86, 0.45, 0.5);
    const shorts = new THREE.Mesh(shortsGeo, whiteMat);
    shorts.position.y = 0.82;
    this.playerGroup.add(shorts);

    const legGeo = new THREE.BoxGeometry(0.28, 0.75, 0.28);

    this.leftLeg = new THREE.Mesh(legGeo, jerseyMat); // Sky blue socks
    this.leftLeg.position.set(-0.24, 0.45, 0);
    this.playerGroup.add(this.leftLeg);

    this.rightLeg = new THREE.Mesh(legGeo, jerseyMat);
    this.rightLeg.position.set(0.24, 0.45, 0);
    this.playerGroup.add(this.rightLeg);

    // Cleats
    const bootGeo = new THREE.BoxGeometry(0.3, 0.18, 0.42);
    const leftBoot = new THREE.Mesh(bootGeo, bootMat);
    leftBoot.position.set(0, -0.32, 0.06);
    this.leftLeg.add(leftBoot);

    const rightBoot = new THREE.Mesh(bootGeo, bootMat);
    rightBoot.position.set(0, -0.32, 0.06);
    this.rightLeg.add(rightBoot);

    // Player Shadow Blob
    const shadowGeo = new THREE.CircleGeometry(0.65, 16);
    const shadowMat = new THREE.MeshBasicMaterial({ color: 0x050911, transparent: true, opacity: 0.45 });
    const shadow = new THREE.Mesh(shadowGeo, shadowMat);
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.02;
    this.playerGroup.add(shadow);

    scene.add(this.playerGroup);

    // ==========================================
    // Soccer Ball
    // ==========================================
    const ballGeo = new THREE.DodecahedronGeometry(0.26, 1);
    this.ballMesh = new THREE.Mesh(ballGeo, ballMat);
    this.ballMesh.position.set(this.position.x + 0.6, 0.26, this.position.z);
    this.ballMesh.name = "etihad-soccer-ball";
    scene.add(this.ballMesh);

    const ballShadowGeo = new THREE.CircleGeometry(0.28, 12);
    this.ballShadow = new THREE.Mesh(ballShadowGeo, shadowMat);
    this.ballShadow.rotation.x = -Math.PI / 2;
    this.ballShadow.position.set(this.ballMesh.position.x, 0.03, this.ballMesh.position.z);
    scene.add(this.ballShadow);

    // Listen to keyboard events
    this.bindKeyboard();
  }

  private bindKeyboard() {
    if (typeof window === "undefined") return;

    window.addEventListener("keydown", (e) => {
      this.keys[e.key.toLowerCase()] = true;
      this.keys[e.code] = true;
      // Disable moveTarget when manual WASD is touched
      if (["KeyW", "KeyA", "KeyS", "KeyD", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) {
        this.moveTarget = null;
      }
    });

    window.addEventListener("keyup", (e) => {
      this.keys[e.key.toLowerCase()] = false;
      this.keys[e.code] = false;
    });
  }

  public update(deltaTime: number, isBallPassing: boolean) {
    const moveDir = new THREE.Vector3(0, 0, 0);

    // 1. Process Keyboard Input
    if (this.keys["w"] || this.keys["arrowup"]) moveDir.z -= 1;
    if (this.keys["s"] || this.arrowDown()) moveDir.z += 1;
    if (this.keys["a"] || this.keys["arrowleft"]) moveDir.x -= 1;
    if (this.keys["d"] || this.keys["arrowright"]) moveDir.x += 1;

    // 2. Process Mobile Joystick Input
    if (Math.abs(this.joystickVector.x) > 0.05 || Math.abs(this.joystickVector.y) > 0.05) {
      moveDir.x += this.joystickVector.x;
      moveDir.z += this.joystickVector.y;
      this.moveTarget = null;
    }

    // 3. Process Point-and-Click Move Target
    if (this.moveTarget && moveDir.lengthSq() === 0) {
      const diff = new THREE.Vector3().subVectors(this.moveTarget, this.position);
      diff.y = 0;
      if (diff.length() > 0.35) {
        moveDir.copy(diff.normalize());
      } else {
        this.moveTarget = null;
      }
    }

    // Calculate movement
    if (moveDir.lengthSq() > 0.001) {
      this.isMoving = true;
      moveDir.normalize();

      const speed = 7.5; // Walk/run speed
      this.velocity.copy(moveDir.clone().multiplyScalar(speed * deltaTime));
      this.position.add(this.velocity);

      // Boundary Clamping inside Etihad Cutaway Diorama
      this.position.x = THREE.MathUtils.clamp(this.position.x, -24.5, 27.5);
      this.position.z = THREE.MathUtils.clamp(this.position.z, -5.6, 5.6);

      // Target heading rotation (smooth slerp)
      const targetHeading = Math.atan2(moveDir.x, moveDir.z);
      // Shortest angle interpolation
      let angleDiff = targetHeading - this.currentHeading;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
      this.currentHeading += angleDiff * Math.min(deltaTime * 12, 1);

      // Walk cycle animation
      this.walkCycleTime += deltaTime * 12;
      const legSwing = Math.sin(this.walkCycleTime) * 0.45;
      const armSwing = Math.cos(this.walkCycleTime) * 0.4;

      this.leftLeg.rotation.x = legSwing;
      this.rightLeg.rotation.x = -legSwing;
      this.leftArm.rotation.x = -armSwing;
      this.rightArm.rotation.x = armSwing;
      this.torso.position.y = 1.35 + Math.abs(Math.sin(this.walkCycleTime * 2)) * 0.05;
    } else {
      this.isMoving = false;
      // Idle return legs/arms
      this.leftLeg.rotation.x *= 0.85;
      this.rightLeg.rotation.x *= 0.85;
      this.leftArm.rotation.x *= 0.85;
      this.rightArm.rotation.x *= 0.85;
      this.torso.position.y = 1.35;
    }

    // Apply rotation & position to player group
    this.playerGroup.position.copy(this.position);
    this.playerGroup.rotation.y = this.currentHeading;

    // Follow Ball (only when ball is not in flight during a curve pass)
    if (!isBallPassing) {
      const ballOffset = new THREE.Vector3(0, 0, 0.7).applyAxisAngle(
        new THREE.Vector3(0, 1, 0),
        this.currentHeading
      );
      const targetBallPos = this.position.clone().add(ballOffset);
      targetBallPos.y = 0.26;

      this.ballMesh.position.lerp(targetBallPos, 0.4);

      if (this.isMoving) {
        // Roll the ball in movement direction
        this.ballMesh.rotation.x += this.velocity.z * 6;
        this.ballMesh.rotation.z -= this.velocity.x * 6;
      }

      this.ballShadow.position.set(this.ballMesh.position.x, 0.03, this.ballMesh.position.z);
    }
  }

  private arrowDown(): boolean {
    return !!this.keys["arrowdown"];
  }

  public setFloorTarget(point: THREE.Vector3) {
    this.moveTarget = point.clone();
    this.moveTarget.y = 0;
  }

  public teleportTo(x: number, z: number) {
    this.position.set(x, 0, z);
    this.playerGroup.position.copy(this.position);
    this.ballMesh.position.set(x + 0.6, 0.26, z);
    this.ballShadow.position.set(x + 0.6, 0.03, z);
    this.moveTarget = null;
  }
}
