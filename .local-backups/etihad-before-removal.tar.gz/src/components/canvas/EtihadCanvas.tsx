"use client";

import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { useStadiumStore, STADIUM_TROPHIES } from "@/store/useStadiumStore";
import type { StadiumZone } from "@/types/stadium";
import { buildEtihadDiorama } from "./EtihadDiorama";
import { PlayerController } from "./PlayerController";

import { CameraRig } from "./CameraRig";
import { InteractiveZoneManager } from "./InteractiveZones";
import { FloatingTrophyBadges } from "./FloatingTrophyBadges";
import { FpsTracker } from "@/lib/telemetry";
import { updateStadiumAmbiance } from "@/lib/audio";

export function EtihadCanvas() {
  const containerRef = useRef<HTMLDivElement>(null);

  // Zustand Store hooks & actions
  const activeZone = useStadiumStore((s) => s.activeZone);
  const viewMode = useStadiumStore((s) => s.viewMode);
  const audioEnabled = useStadiumStore((s) => s.audioEnabled);
  const setFps = useStadiumStore((s) => s.setFps);
  const setPlayerCoordinates = useStadiumStore((s) => s.setPlayerCoordinates);
  const setPlayerHeading = useStadiumStore((s) => s.setPlayerHeading);

  const setActiveZone = useStadiumStore((s) => s.setActiveZone);

  // Stable references across renders
  const playerControllerRef = useRef<PlayerController | null>(null);

  const cameraRigRef = useRef<CameraRig | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // 1. Scene Setup with Deep Etihad Night and Subtle Fog
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x040814); // Deep Etihad Night
    scene.fog = new THREE.FogExp2(0x040814, 0.016); // Soft fading boundary fog

    // 2. Camera Setup (Isometric CameraRig)
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    const cameraRig = new CameraRig(width, height);
    cameraRigRef.current = cameraRig;

    // 3. Renderer Setup
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: "high-performance",
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    renderer.shadowMap.enabled = false; // Baked & procedural toon shadows as per PRD rule
    container.appendChild(renderer.domElement);

    // 4. Lighting Setup (Stadium Floodlights)
    const ambientLight = new THREE.AmbientLight(0xe8f0fe, 1.2);
    scene.add(ambientLight);

    // Key stadium floodlight
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.6);
    keyLight.position.set(15, 24, 18);
    scene.add(keyLight);

    // Soft Sky Blue rim light from opposite angle
    const rimLight = new THREE.DirectionalLight(0x6cabdd, 3.0);
    rimLight.position.set(-20, 15, -12);
    scene.add(rimLight);

    // Warm ground bounce
    const groundFill = new THREE.DirectionalLight(0x22354d, 1.4);
    groundFill.position.set(0, -5, 0);
    scene.add(groundFill);

    // 5. Build 3D Etihad Diorama
    const interactiveObjects = buildEtihadDiorama(scene);

    // 6. Player Controller (#17) & Ball
    const playerController = new PlayerController(scene);
    playerControllerRef.current = playerController;


    // 8. Interactive Zone Raycasting Manager
    const zoneManager = new InteractiveZoneManager(scene, interactiveObjects);

    // 9. FPS Tracker
    const fpsTracker = new FpsTracker((fps) => {
      setFps(fps);
    });

    // 10. Animation Loop
    let lastTime = performance.now();
    let animId: number;

    const animate = (currentTime: number) => {
      animId = requestAnimationFrame(animate);
      const deltaTime = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;

      // Track FPS
      fpsTracker.tick();

      // Get latest state
      const currentViewMode = useStadiumStore.getState().viewMode;
      const currentActiveZone = useStadiumStore.getState().activeZone;
      const isAudioOn = useStadiumStore.getState().audioEnabled;

      // Update Player movement & animation
      playerController.update(deltaTime, false);

      // Update Zustand player position & heading state
      setPlayerCoordinates([
        playerController.position.x,
        playerController.position.y,
        playerController.position.z,
      ]);
      setPlayerHeading(playerController.currentHeading);

      // Detect current Zone based on player X position
      const px = playerController.position.x;
      let detectedZone = currentActiveZone;
      if (px < -14) detectedZone = "dressing-room";
      else if (px >= -14 && px < -2) detectedZone = "var-room";
      else if (px >= -2 && px < 10) detectedZone = "glass-tunnel";
      else detectedZone = "pitch";

      if (detectedZone !== currentActiveZone) {
        setActiveZone(detectedZone);
        // Modulate stadium crowd noise as player approaches the pitch
        const zoneVolume = detectedZone === "pitch" ? 0.22 : detectedZone === "glass-tunnel" ? 0.15 : 0.08;
        updateStadiumAmbiance(isAudioOn, zoneVolume);
      }

      // In Zone 2 (VAR & Trophy Room), dynamically highlight the closest trophy
      if (px >= -14 && px < -2) {
        let closestTrophy: (typeof STADIUM_TROPHIES)[0] | null = null;
        let minDistance = 3.6;
        for (const trophy of STADIUM_TROPHIES) {
          const tObj = interactiveObjects.trophies.find((t) => t.id === trophy.id);
          if (tObj) {
            const dist = Math.hypot(
              playerController.position.x - tObj.position[0],
              playerController.position.z - tObj.position[2]
            );
            if (dist < minDistance) {
              minDistance = dist;
              closestTrophy = trophy;
            }
          }
        }
        if (closestTrophy && closestTrophy.id !== useStadiumStore.getState().activeHoveredProject?.id) {
          useStadiumStore.getState().setActiveHoveredProject(closestTrophy);
        }
      }

      // Update Dynamic VAR Screens
      if (interactiveObjects.updateVarScreens) {
        interactiveObjects.updateVarScreens(
          useStadiumStore.getState().activeHoveredProject,
          currentTime / 1000
        );
      }

      // Update Interactive floating indicators & animations
      zoneManager.update(deltaTime);

      // Update Camera Tracking & Isometric view
      cameraRig.update(deltaTime, playerController.position, detectedZone, currentViewMode);

      // Render
      renderer.render(scene, cameraRig.camera);
    };

    animId = requestAnimationFrame(animate);

    // 11. Click / Tap Event Handling
    const handleClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;

      const hit = zoneManager.testRaycast(
        clientX,
        clientY,
        rect.width,
        rect.height,
        cameraRig.camera
      );

      if (hit.targetType === "locker" && hit.targetId) {
        useStadiumStore.getState().openLocker(hit.targetId as "tiki-taka" | "engine" | "visionary");
      } else if (hit.targetType === "trophy" && hit.targetId) {
        useStadiumStore.getState().openTrophy(hit.targetId);
      } else if (hit.targetType === "milestone" && hit.targetId) {
        useStadiumStore.getState().openMilestone(hit.targetId);
      } else if (hit.targetType === "jumbotron") {
        useStadiumStore.getState().openJumbotron();
      } else if (hit.targetType === "floor") {
        // Move character to clicked floor point
        playerController.setFloorTarget(hit.targetPosition);
      }
    };

    // Keyboard shortcut [Enter] to inspect VAR case study
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter") {
        const hovered = useStadiumStore.getState().activeHoveredProject;
        if (hovered && !useStadiumStore.getState().selectedTrophy) {
          useStadiumStore.getState().openTrophy(hovered.id);
        }
      }
    };

    const domElement = renderer.domElement;
    domElement.addEventListener("click", handleClick);
    window.addEventListener("keydown", handleKeyDown);

    // 12. Window Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      cameraRig.resize(newWidth, newHeight);
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener("resize", handleResize);

    // Cleanup on unmount
    return () => {
      cancelAnimationFrame(animId);
      domElement.removeEventListener("click", handleClick);
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
      if (container.contains(domElement)) {
        container.removeChild(domElement);
      }
    };
  }, [setActiveZone, setFps, setPlayerCoordinates, setPlayerHeading]);

  // Handle minimap zone navigation jumps
  useEffect(() => {
    if (cameraRigRef.current) {
      cameraRigRef.current.focusZone(activeZone);
    }
    if (playerControllerRef.current) {
      const zoneTargets: Record<StadiumZone, [number, number]> = {
        "dressing-room": [-20, 0],
        "var-room": [-8, 0],
        "glass-tunnel": [4, 0],
        "pitch": [18, 0],
      };
      const [tx, tz] = zoneTargets[activeZone] || [18, 0];
      const currentPos = playerControllerRef.current.position;
      const isAlreadyInZone =
        (activeZone === "dressing-room" && currentPos.x < -14) ||
        (activeZone === "var-room" && currentPos.x >= -14 && currentPos.x < -2) ||
        (activeZone === "glass-tunnel" && currentPos.x >= -2 && currentPos.x < 10) ||
        (activeZone === "pitch" && currentPos.x >= 10);

      if (!isAlreadyInZone) {
        playerControllerRef.current.teleportTo(tx, tz);
      }
    }
  }, [activeZone]);

  // Handle audio state toggle
  useEffect(() => {
    updateStadiumAmbiance(audioEnabled, activeZone === "pitch" ? 0.22 : 0.1);
  }, [audioEnabled, activeZone]);

  return (
    <div
      className={`absolute inset-0 w-full h-full overflow-hidden select-none transition-opacity duration-500 ${
        viewMode === "tactical-2d" ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      <div
        ref={containerRef}
        className="w-full h-full"
        style={{ cursor: "crosshair" }}
      />
      <FloatingTrophyBadges getCamera={() => cameraRigRef.current?.camera || null} />
    </div>
  );
}
