import * as THREE from "three";
import { playKickSound, playGoalCheer } from "@/lib/audio";

export interface CurvePassInstance {
  startPos: THREE.Vector3;
  targetPos: THREE.Vector3;
  controlPoint: THREE.Vector3;
  duration: number; // in seconds, typically 0.50s - 0.58s (< 0.6s as in PRD)
  elapsed: number;
  targetType: "locker" | "trophy" | "milestone" | "jumbotron" | "floor" | null;
  targetId: string | null;
  onComplete: () => void;
}

export class CurvePassManager {
  private activePass: CurvePassInstance | null = null;
  private particleGroup: THREE.Group;
  private ballMesh: THREE.Mesh;
  private ballShadow: THREE.Mesh;

  constructor(scene: THREE.Scene, ballMesh: THREE.Mesh, ballShadow: THREE.Mesh) {
    this.ballMesh = ballMesh;
    this.ballShadow = ballShadow;

    this.particleGroup = new THREE.Group();
    this.particleGroup.name = "curve-pass-particles";
    scene.add(this.particleGroup);
  }

  public launchPass(
    start: THREE.Vector3,
    target: THREE.Vector3,
    targetType: CurvePassInstance["targetType"],
    targetId: string | null,
    audioEnabled: boolean,
    onComplete: () => void
  ) {
    // Sound FX: Instant kick impact
    playKickSound(audioEnabled);

    // Compute 3D Quadratic Bezier Control Point
    // P1 sits halfway between Start and Target, elevated into the air
    const midX = (start.x + target.x) / 2;
    const midZ = (start.z + target.z) / 2;
    const distance = start.distanceTo(target);
    const elevation = Math.max(3.5, distance * 0.22);
    const midY = Math.max(start.y, target.y) + elevation;

    const controlPoint = new THREE.Vector3(midX, midY, midZ);

    this.activePass = {
      startPos: start.clone(),
      targetPos: target.clone(),
      controlPoint,
      duration: Math.min(0.58, Math.max(0.38, distance * 0.025)),
      elapsed: 0,
      targetType,
      targetId,
      onComplete,
    };
  }

  public update(deltaTime: number, audioEnabled: boolean): boolean {
    if (!this.activePass) return false;

    this.activePass.elapsed += deltaTime;
    const t = Math.min(this.activePass.elapsed / this.activePass.duration, 1);

    // 3D Quadratic Bezier Formula:
    // B(t) = (1-t)^2 * P0 + 2(1-t)t * P1 + t^2 * P2
    const oneMinusT = 1 - t;
    const p0 = this.activePass.startPos;
    const p1 = this.activePass.controlPoint;
    const p2 = this.activePass.targetPos;

    const currentX = oneMinusT * oneMinusT * p0.x + 2 * oneMinusT * t * p1.x + t * t * p2.x;
    const currentY = oneMinusT * oneMinusT * p0.y + 2 * oneMinusT * t * p1.y + t * t * p2.y;
    const currentZ = oneMinusT * oneMinusT * p0.z + 2 * oneMinusT * t * p1.z + t * t * p2.z;

    this.ballMesh.position.set(currentX, currentY, currentZ);

    // Dynamic Ball Spin while airborne
    this.ballMesh.rotation.x += deltaTime * 20;
    this.ballMesh.rotation.z += deltaTime * 14;

    // Ground shadow projection
    this.ballShadow.position.set(currentX, 0.03, currentZ);
    // Shadow size shrinks when high in the air
    const heightFactor = Math.max(0.3, 1 - (currentY / 8));
    this.ballShadow.scale.set(heightFactor, heightFactor, 1);

    // Check completion
    if (t >= 1) {
      const { targetType, onComplete } = this.activePass;

      // Special Goal cheer if hitting the Jumbotron
      if (targetType === "jumbotron") {
        playGoalCheer(audioEnabled);
      } else {
        playKickSound(audioEnabled);
      }

      this.spawnImpactParticles(p2);
      this.activePass = null;
      onComplete();
      return false;
    }

    return true; // Still passing
  }

  public isPassing(): boolean {
    return this.activePass !== null;
  }

  private spawnImpactParticles(pos: THREE.Vector3) {
    const ringGeo = new THREE.RingGeometry(0.2, 0.45, 16);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x00e5ff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.copy(pos);
    ring.rotation.x = -Math.PI / 2;
    this.particleGroup.add(ring);

    // Quick ring expansion and fade out
    let scale = 1;
    const interval = setInterval(() => {
      scale += 0.3;
      ring.scale.set(scale, scale, 1);
      ringMat.opacity -= 0.12;

      if (ringMat.opacity <= 0) {
        clearInterval(interval);
        this.particleGroup.remove(ring);
        ringGeo.dispose();
        ringMat.dispose();
      }
    }, 25);
  }
}
