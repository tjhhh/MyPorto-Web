"use client";

import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { useStadiumStore, STADIUM_TROPHIES } from "@/store/useStadiumStore";
import type { TrophyProject } from "@/types/stadium";
import { Zap, ChevronDown, CheckCircle2 } from "lucide-react";

interface FloatingTrophyBadgesProps {
  getCamera: () => THREE.Camera | null;
}

// Exact 3D world coordinates for the 6 trophy heads
const TROPHY_COORDS: { id: string; pos: [number, number, number] }[] = [
  { id: "futsalpro", pos: [-12.2, 2.6, -1.6] },
  { id: "smart-kandang", pos: [-8.0, 2.7, -1.6] },
  { id: "rideassist", pos: [-3.8, 2.5, -1.6] },
  { id: "hikepass-mobile", pos: [-12.2, 2.6, 2.6] },
  { id: "idaman-tsl", pos: [-8.0, 2.6, 2.6] },
  { id: "bank-sampah", pos: [-3.8, 2.5, 2.6] },
];

export function FloatingTrophyBadges({ getCamera }: FloatingTrophyBadgesProps) {
  const viewMode = useStadiumStore((s) => s.viewMode);
  const activeHoveredProject = useStadiumStore((s) => s.activeHoveredProject);
  const setActiveHoveredProject = useStadiumStore((s) => s.setActiveHoveredProject);
  const openTrophy = useStadiumStore((s) => s.openTrophy);

  const badgeRefs = useRef<{ [id: string]: HTMLDivElement | null }>({});

  useEffect(() => {
    let animId: number;

    const updateBadgePositions = () => {
      animId = requestAnimationFrame(updateBadgePositions);

      const camera = getCamera();
      if (!camera || viewMode === "tactical-2d") return;

      const width = window.innerWidth;
      const height = window.innerHeight;

      TROPHY_COORDS.forEach(({ id, pos }) => {
        const el = badgeRefs.current[id];
        if (!el) return;

        const vec = new THREE.Vector3(pos[0], pos[1], pos[2]);
        vec.project(camera);

        // Check if behind camera
        if (vec.z > 1.0) {
          el.style.display = "none";
          return;
        }

        const screenX = (vec.x * 0.5 + 0.5) * width;
        const screenY = (-vec.y * 0.5 + 0.5) * height;

        // Check viewport bounds
        if (screenX < -150 || screenX > width + 150 || screenY < -100 || screenY > height + 100) {
          el.style.display = "none";
          return;
        }

        el.style.display = "block";
        el.style.transform = `translate3d(${screenX}px, ${screenY}px, 0) translate(-50%, -100%)`;
      });
    };

    animId = requestAnimationFrame(updateBadgePositions);

    return () => cancelAnimationFrame(animId);
  }, [getCamera, viewMode]);

  if (viewMode === "tactical-2d") return null;

  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none overflow-hidden select-none z-20"
    >
      {STADIUM_TROPHIES.map((project: TrophyProject) => {
        const isHovered = activeHoveredProject?.id === project.id;

        return (
          <div
            key={project.id}
            ref={(el) => {
              badgeRefs.current[project.id] = el;
            }}
            className="absolute top-0 left-0 pointer-events-auto will-change-transform transition-opacity duration-200"
            style={{ display: "none" }}
            onMouseEnter={() => setActiveHoveredProject(project)}
            onClick={(e) => {
              e.stopPropagation();
              openTrophy(project.id);
            }}
          >
            <div
              className={`group flex flex-col items-center cursor-pointer transition-all duration-200 ${
                isHovered ? "scale-105" : "hover:scale-105"
              }`}
            >
              {/* Badge Surface */}
              <div
                className={`relative px-3 py-1.5 rounded-lg border backdrop-blur-md shadow-xl transition-all ${
                  isHovered
                    ? "bg-[#0a1628]/95 border-[#38bdf8] shadow-[0_0_20px_rgba(56,189,248,0.45)] ring-1 ring-[#38bdf8]"
                    : "bg-[#070e1c]/85 border-[#38bdf8]/35 hover:border-[#38bdf8] shadow-black/60"
                }`}
              >
                {/* Top Mini Tag & Live Status Indicator */}
                <div className="flex items-center justify-between gap-2 pb-0.5 border-b border-white/10 mb-1">
                  <div className="flex items-center gap-1.5">
                    <span
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ backgroundColor: project.trophyColor }}
                    />
                    <span className="font-mono text-[9px] font-bold tracking-wider text-white/70">
                      Z2 TROPHY
                    </span>
                  </div>
                  <span className="font-mono text-[8px] text-[#38bdf8] font-bold px-1 bg-[#00285e]/60 rounded">
                    VAR
                  </span>
                </div>

                {/* Project Title */}
                <h4 className="font-mono text-xs font-black text-white tracking-tight truncate max-w-[190px]">
                  {project.title}
                </h4>

                {/* Key Metric Pill */}
                <div className="flex items-center gap-1.5 mt-1 px-1.5 py-0.5 rounded bg-black/50 border border-white/10 font-mono text-[10px]">
                  <Zap className="w-3 h-3 text-[#38bdf8] shrink-0" />
                  <span className="font-bold text-[#34d399] tracking-tight">
                    {project.badgeMetric}
                  </span>
                </div>

                {/* Click to Inspect Prompt on hover */}
                {isHovered && (
                  <div className="mt-1 pt-1 border-t border-[#38bdf8]/30 flex items-center justify-center gap-1 font-mono text-[9px] text-[#38bdf8] font-bold animate-pulse">
                    <CheckCircle2 className="w-2.5 h-2.5" />
                    <span>KLIK ATAU TEKAN [ENTER]</span>
                  </div>
                )}
              </div>

              {/* Downward Pointer Triangle */}
              <div
                className={`w-0 h-0 border-x-4 border-x-transparent border-t-6 transition-colors ${
                  isHovered ? "border-t-[#38bdf8]" : "border-t-[#38bdf8]/50"
                }`}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
