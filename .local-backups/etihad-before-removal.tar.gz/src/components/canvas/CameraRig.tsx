import * as THREE from "three";
import type { StadiumZone, ViewMode } from "@/types/stadium";

/**
 * Isometric Camera Rig with zone damping & smooth transitions
 */

export class CameraRig {
  public camera: THREE.PerspectiveCamera;
  private currentLookAt: THREE.Vector3 = new THREE.Vector3(18, 0, 0);
  private targetLookAt: THREE.Vector3 = new THREE.Vector3(18, 0, 0);

  // Isometric Offset from lookAt center
  // Isometric vector: [dx, dy, dz] = [15, 17, 18]
  private isoOffset = new THREE.Vector3(14, 18, 16);

  // Zone Focal Positions
  private zoneAnchors: Record<StadiumZone, THREE.Vector3> = {
    "dressing-room": new THREE.Vector3(-20, 1.2, 0),
    "var-room": new THREE.Vector3(-8, 1.2, 0),
    "glass-tunnel": new THREE.Vector3(4, 1.2, 0),
    "pitch": new THREE.Vector3(19, 1.2, 0),
  };

  constructor(width: number, height: number) {
    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.5, 200);

    const initialPos = this.zoneAnchors["pitch"].clone().add(this.isoOffset);
    this.camera.position.copy(initialPos);
    this.camera.lookAt(this.zoneAnchors["pitch"]);
  }

  public update(
    deltaTime: number,
    playerPos: THREE.Vector3,
    activeZone: StadiumZone,
    viewMode: ViewMode
  ) {
    if (viewMode === "tactical-2d") {
      // Zoom-out overhead view transition for 2D mode
      const overheadPos = new THREE.Vector3(2, 36, 0);
      this.camera.position.lerp(overheadPos, Math.min(deltaTime * 4, 1));
      this.targetLookAt.set(2, 0, 0);
      this.currentLookAt.lerp(this.targetLookAt, Math.min(deltaTime * 4, 1));
      this.camera.lookAt(this.currentLookAt);
      return;
    }

    // Dynamic Tracking in 3D Mode:
    // Blend between Player position and Zone focal point
    const zoneAnchor = this.zoneAnchors[activeZone];
    this.targetLookAt.copy(playerPos.clone().multiplyScalar(0.65).add(zoneAnchor.clone().multiplyScalar(0.35)));

    // Smooth lerp lookAt
    this.currentLookAt.lerp(this.targetLookAt, Math.min(deltaTime * 5, 1));

    // Target Camera Position = lookAt + isometric offset
    const desiredCameraPos = this.currentLookAt.clone().add(this.isoOffset);

    // Smooth lerp camera movement
    this.camera.position.lerp(desiredCameraPos, Math.min(deltaTime * 4.5, 1));
    this.camera.lookAt(this.currentLookAt);
  }

  public resize(width: number, height: number) {
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }

  public focusZone(zone: StadiumZone) {
    const anchor = this.zoneAnchors[zone];
    this.targetLookAt.copy(anchor);
  }
}
