export type StadiumZone = "dressing-room" | "var-room" | "glass-tunnel" | "pitch";

export type ViewMode = "3d" | "tactical-2d";

export interface LockerSkill {
  id: "tiki-taka" | "engine" | "visionary";
  number: number;
  playstyle: string;
  badgeTitle: string;
  category: string;
  headline: string;
  overallRating: number;
  position: "FWD" | "MID" | "SYS";
  pace: number;
  shooting: number;
  passing: number;
  dribbling: number;
  defending: number;
  physical: number;
  keySkills: string[];
  signatureTrait: string;
  description: string;
  color: string;
}

export interface TrophyProject {
  id: string;
  slug: string;
  title: string;
  type: string;
  year: string;
  role: string;
  team: string;
  description: string;
  image: string;
  tags: string[];
  metrics: { value: string; label: string }[];
  tacticalArchitecture: {
    frontend: string;
    backend: string;
    infrastructure: string;
    dataPipeline: string;
  };
  highlights: string[];
  repoUrl: string | null;
  liveUrl: string | null;
  detailHref: string;
  trophyColor: string;
  badgeMetric: string;
  badgeShape: "gateway" | "futsal" | "gear" | "mountain" | "database" | "leaf";
}

export interface TunnelMilestone {
  id: string;
  period: string;
  role: string;
  organization: string;
  type: "Internship & Production" | "Teaching & Academic" | "Undergraduate";
  headline: string;
  summary: string;
  deliverables: string[];
  telemetryMetric?: string;
  accent: string;
}

export interface BallPassState {
  isPassing: boolean;
  startX: number;
  startY: number;
  startZ: number;
  targetX: number;
  targetY: number;
  targetZ: number;
  curveHeight: number;
  progress: number;
  targetType: "locker" | "trophy" | "milestone" | "jumbotron" | "floor" | null;
  targetId: string | null;
}
