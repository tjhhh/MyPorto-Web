import { create } from "zustand";
import type {
  BallPassState,
  LockerSkill,
  StadiumZone,
  TrophyProject,
  TunnelMilestone,
  ViewMode,
} from "@/types/stadium";

export const STADIUM_LOCKERS: LockerSkill[] = [
  {
    id: "tiki-taka",
    number: 17,
    playstyle: "Tiki-Taka+",
    badgeTitle: "PLAYSTYLE+ TIKI-TAKA",
    category: "Frontend & Mobile Architecture",
    headline: "Fluid Reactive Interfaces & Ultra-Responsive Mobile Systems",
    overallRating: 93,
    position: "FWD",
    pace: 94,
    shooting: 89,
    passing: 97,
    dribbling: 95,
    defending: 82,
    physical: 86,
    keySkills: ["Flutter", "Next.js", "React 19", "TypeScript", "Tailwind CSS", "Zustand"],
    signatureTrait: "Sub-50ms Frame Delivery & Kinetic Micro-Animations",
    description:
      "Ahli dalam merancang pengalaman pengguna berkecepatan tinggi, state synchronization multi-tier, arsitektur Clean/MVVM di Flutter, dan performa web server-rendered berskala produksi.",
    color: "#00E5FF",
  },
  {
    id: "engine",
    number: 8,
    playstyle: "Engine+",
    badgeTitle: "PLAYSTYLE+ RELENTLESS ENGINE",
    category: "Backend Microservices & Cloud Schemas",
    headline: "High-Throughput Relational Databases & Distributed Microservices",
    overallRating: 92,
    position: "MID",
    pace: 90,
    shooting: 86,
    passing: 93,
    dribbling: 88,
    defending: 92,
    physical: 94,
    keySkills: ["NestJS", "Node.js", "Supabase", "PostgreSQL", "Prisma ORM", "REST / GraphQL", "Docker"],
    signatureTrait: "Strict Schema Constraints & Realtime Ingestion Pipelines",
    description:
      "Merancang backend modular berperforma tinggi, skema PostgreSQL teroptimasi, role-based access control (RBAC), middleware validasi payload ketat, dan integrasi webhook pembayaran andal.",
    color: "#6CABDD",
  },
  {
    id: "visionary",
    number: 10,
    playstyle: "Visionary+",
    badgeTitle: "PLAYSTYLE+ INCISIVE PASS",
    category: "IoT Telemetry, Automation & Algorithms",
    headline: "Sensor Edge Ingestion, Automated QA & Systems Discipline",
    overallRating: 91,
    position: "SYS",
    pace: 88,
    shooting: 85,
    passing: 95,
    dribbling: 89,
    defending: 94,
    physical: 91,
    keySkills: ["ESP32 / Edge Telemetry", "MQTT / HTTP", "Automated QA", "Algoritma & Data", "CI/CD"],
    signatureTrait: "<500ms Edge-to-Cloud Telemetry & Zero-Defect Code Auditing",
    description:
      "Menjembatani hardware edge IoT dengan dashboard analitik cloud, mengotomasi pengujian perangkat lunak (White/Black Box), dan optimasi komputasi berbasis data real-time.",
    color: "#FFD700",
  },
];

export const STADIUM_TROPHIES: TrophyProject[] = [
  {
    id: "futsalpro",
    slug: "futsalpro",
    title: "FutsalPro Enterprise",
    type: "Full-Stack Booking Platform",
    role: "Solo Architect & Fullstack Engineer",
    team: "Solo Project",
    year: "2024",
    description:
      "Platform manajemen fasilitas olahraga multi-lapangan berbasis web dengan sistem reservasi otomatis, verifikasi webhook Midtrans, dan pengiriman invoice email transaksional Resend.",
    image: "/futsalpro/FutsalPro_TN.jpg",
    tags: ["Next.js", "Tailwind CSS", "Supabase", "PostgreSQL", "Midtrans", "Resend"],
    metrics: [
      { value: "100%", label: "Automated Bookings" },
      { value: "<1.2s", label: "Checkout Latency" },
      { value: "0", label: "Double Booking Collisions" },
    ],
    tacticalArchitecture: {
      frontend: "Next.js App Router, Tailwind CSS, Optimistic State",
      backend: "Next.js Server Actions, REST Webhook Endpoints",
      infrastructure: "Vercel Edge Network, Cloudflare DNS",
      dataPipeline: "Supabase PostgreSQL dengan Row-Level Security & Database Locks",
    },
    highlights: [
      "Penanganan transaksi atomik untuk mencegah tabrakan jadwal ganda di slot waktu puncak.",
      "Webhook payment gateway terenkripsi dengan notifikasi invoice real-time.",
      "Dashboard admin dengan analitik okupansi lapangan mingguan dan bulanan.",
    ],
    repoUrl: "https://github.com/tjhhh/FutsalPro",
    liveUrl: "https://futsalpro.my.id",
    detailHref: "/projects/futsalpro",
    trophyColor: "#10B981", // Emerald
    badgeMetric: "0 Collision • Midtrans",
    badgeShape: "futsal",
  },
  {
    id: "smart-kandang",
    slug: "smart-kandang",
    title: "Smart Kandang IoT Ecosystem",
    type: "IoT Telemetry & Multi-Platform System",
    role: "Fullstack & Ingestion Engineer",
    team: "COE Telkom Univ Team",
    year: "2024",
    description:
      "Ekosistem perangkat lunak terpadu pemantau closed-house broiler: Web Dashboard Next.js, Mobile App Flutter, dan backend NestJS yang menelan telemetri edge ESP32 real-time.",
    image: "/futsalpro-dashboard.png",
    tags: ["NestJS", "Flutter", "Next.js", "ESP32", "PostgreSQL", "Prisma"],
    metrics: [
      { value: "<500ms", label: "Edge-to-Cloud Latency" },
      { value: ">95%", label: "Triage Alert Efficiency" },
      { value: "24/7", label: "Microclimate Telemetry" },
    ],
    tacticalArchitecture: {
      frontend: "Next.js 14 Web Dashboard + Flutter MVVM Mobile App",
      backend: "NestJS Modular Microservices dengan Prisma ORM",
      infrastructure: "Self-hosted Cloud VPS, ESP32 Gateway via MQTT/HTTP",
      dataPipeline: "PostgreSQL Time-Series Ingestion & In-browser Excel/CSV Generator",
    },
    highlights: [
      "Pipeline penyerapan data telemetri suhu, kelembaban, amonia, dan heat index tanpa latency.",
      "Sistem bulk alert acknowledge memangkas waktu respons darurat dari 3 menit ke <5 detik.",
      "Generator laporan analitik multi-sheet diproses di peramban tanpa membebani server.",
    ],
    repoUrl: "https://github.com/tjhhh",
    liveUrl: null,
    detailHref: "/projects/futsalpro",
    trophyColor: "#F59E0B", // Gold/Cyan
    badgeMetric: "<500ms Latency",
    badgeShape: "gateway",
  },
  {
    id: "rideassist",
    slug: "rideassist",
    title: "RideAssist Mobile Companion",
    type: "Mobile Vehicle Telemetry App",
    role: "Mobile App Lead",
    team: "Solo Project",
    year: "2024",
    description:
      "Aplikasi mobile asistensi perawatan kendaraan bermotor dengan pelacakan riwayat servis berkala, pengingat odometer dinamis, dan sinkronisasi cloud Firebase real-time.",
    image: "/rideassist/RideAssists_TN.jpg",
    tags: ["Flutter", "Firebase", "Dart", "Clean Architecture", "Local Storage"],
    metrics: [
      { value: "60 FPS", label: "Mobile Render Speed" },
      { value: "Offline", label: "First Architecture" },
      { value: "100%", label: "Sync Reliability" },
    ],
    tacticalArchitecture: {
      frontend: "Flutter Clean Architecture dengan BLoC/Provider state pattern",
      backend: "Firebase Cloud Firestore & Authentication",
      infrastructure: "Google Cloud Platform Services",
      dataPipeline: "Offline-first Cache dengan background sync otomatis saat online",
    },
    highlights: [
      "Pelacakan siklus hidup suku cadang berdasarkan estimasi jarak tempuh aktual.",
      "Penyimpanan offline lokal yang menjamin data tetap dapat dicatat di area tanpa sinyal.",
      "Visualisasi analitik pengeluaran biaya perawatan kendaraan per kuartal.",
    ],
    repoUrl: "https://github.com/tjhhh/ServiceLog-RideAssisst",
    liveUrl: null,
    detailHref: "/projects/rideassist",
    trophyColor: "#F97316", // Orange/Red
    badgeMetric: "60 FPS • Offline-First",
    badgeShape: "gear",
  },
  {
    id: "hikepass-mobile",
    slug: "hikepass-mobile",
    title: "HikePass Wilderness Platform",
    type: "Wilderness Ticketing & Verification",
    role: "Mobile Systems Engineer",
    team: "Group Project",
    year: "2023",
    description:
      "Aplikasi mobile untuk penjelajah gunung dan petugas pos registrasi, dilengkapi tiket digital dengan verifikasi barcode offline, manajemen kuota jalur, dan notifikasi cuaca.",
    image: "/hikepass-mobile/Hikepass-Mobile_TN.jpg",
    tags: ["Flutter", "Supabase", "GetX", "Resend", "QR Scanner"],
    metrics: [
      { value: "<100ms", label: "QR Pass Verification" },
      { value: "Offline", label: "Gate Check-in" },
      { value: "4.9/5", label: "Field Test Score" },
    ],
    tacticalArchitecture: {
      frontend: "Flutter dengan GetX State & Navigation",
      backend: "Supabase Edge Functions & REST Endpoints",
      infrastructure: "Supabase Managed Cloud",
      dataPipeline: "Signed Offline QR Tokens dengan enkripsi lokal",
    },
    highlights: [
      "Verifikasi tiket di pos pendakian tanpa koneksi internet menggunakan token QR bertanda tangan.",
      "Manajemen kapasitas kuota pendakian harian secara real-time.",
      "Email tiket otomatis dengan panduan keselamatan jalur pendakian.",
    ],
    repoUrl: "https://github.com/hikepassapp/hikepassApp",
    liveUrl: null,
    detailHref: "/projects/hikepass-mobile",
    trophyColor: "#14B8A6", // Teal
    badgeMetric: "<100ms QR Verify",
    badgeShape: "mountain",
  },
  {
    id: "idaman-tsl",
    slug: "idaman-tsl",
    title: "IDAMAN-TSL BBKSDA",
    type: "Wildlife Conservation Registry",
    role: "Frontend Engineer",
    team: "Collaboration Team",
    year: "2023",
    description:
      "Sistem informasi data pemanfaatan tumbuhan dan satwa liar untuk Balai Besar Konservasi Sumber Daya Alam (BBKSDA) Jawa Barat dengan kepatuhan audit regulasi ketat.",
    image: "/idamantsl/IDAMANTSL_TN.jpg",
    tags: ["Next.js", "Tailwind CSS", "TypeScript", "Data Table"],
    metrics: [
      { value: "100%", label: "Audit Accuracy" },
      { value: "<2s", label: "Complex Report Render" },
      { value: "Gov-Grade", label: "Data Strictness" },
    ],
    tacticalArchitecture: {
      frontend: "Next.js dengan Server-Side Rendering dan Tailwind CSS",
      backend: "Enterprise REST API",
      infrastructure: "Provincial Government Server Infrastructure",
      dataPipeline: "Relational database dengan jejak audit mutasi data komprehensif",
    },
    highlights: [
      "Tabel data multi-filter canggih untuk memantau status legalitas izin penangkaran flora & fauna.",
      "Formulir entri bertahap dengan validasi integritas taksonomi satwa.",
      "Ekspor dokumen laporan resmi berformat standar kementerian lingkungan hidup.",
    ],
    repoUrl: null,
    liveUrl: null,
    detailHref: "/projects/idaman-tsl",
    trophyColor: "#A855F7", // Purple/Silver
    badgeMetric: "100% Audit Accuracy",
    badgeShape: "database",
  },
  {
    id: "bank-sampah",
    slug: "bank-sampah",
    title: "HijauKu Smart Recycling",
    type: "Community Waste Banking Calculator",
    role: "Frontend Engineer",
    team: "Group Project",
    year: "2023",
    description:
      "Website interaktif dan kalkulator daur ulang digital untuk mengedukasi warga, menghitung konversi berat sampah menjadi nilai ekonomi, dan memantau tabungan daur ulang.",
    image: "/hijauku/HijauKu_TN.jpg",
    tags: ["HTML5", "CSS3", "JavaScript", "Bootstrap"],
    metrics: [
      { value: "100%", label: "Client-Side Processing" },
      { value: "<1s", label: "Instant Calculator" },
      { value: "Zero-Lag", label: "Mobile Browser UX" },
    ],
    tacticalArchitecture: {
      frontend: "Modern Semantic HTML5, CSS Variables, Modular Vanilla JS",
      backend: "Serverless Static Deployment",
      infrastructure: "GitHub Pages CDN",
      dataPipeline: "Client-side formula engine untuk konversi gramatur limbah anorganik",
    },
    highlights: [
      "Kalkulator konversi harga sampah anorganik interaktif dengan umpan balik visual instan.",
      "Katalog jenis sampah yang dapat didaur ulang beserta tips pemilahan rumah tangga.",
      "Desain adaptif yang sangat ringan dan ramah untuk segala jenis smartphone warga.",
    ],
    repoUrl: null,
    liveUrl: "https://simplix07.github.io/bankSampah1.2/",
    detailHref: "/projects/bank-sampah",
    trophyColor: "#22C55E", // Green
    badgeMetric: "Instant Client Calc",
    badgeShape: "leaf",
  },
];

export const STADIUM_MILESTONES: TunnelMilestone[] = [
  {
    id: "coe-telkom",
    period: "Agustus 2024 — Sekarang",
    role: "Fullstack & IoT Telemetry Developer",
    organization: "COE Integrated & Embedded System, Telkom University Surabaya",
    type: "Internship & Production",
    headline: "Smart Kandang Multi-Platform Software & Telemetry Ingestion Ecosystem",
    summary:
      "Memimpin perancangan arsitektur perangkat lunak terintegrasi (Web Dashboard Next.js, Mobile App Flutter, dan Backend NestJS) untuk penyerapan data telemetri gateway ESP32 pada sistem closed-house broiler.",
    deliverables: [
      "Mengembangkan pipeline telemetri real-time dengan latensi ujung-ke-ujung <500ms.",
      "Merancang aplikasi mobile Flutter dengan arsitektur Clean/MVVM dan notifikasi darurat FCM.",
      "Mengimplementasikan generator laporan audit multi-kandang client-side berkecepatan tinggi.",
    ],
    telemetryMetric: "<500ms Latency // 24/7 Production",
    accent: "#00E5FF",
  },
  {
    id: "asisten-lab",
    period: "Februari 2024 — Juni 2024",
    role: "Teaching Assistant / Asisten Praktikum",
    organization: "Fakultas Informatika, Telkom University Surabaya",
    type: "Teaching & Academic",
    headline: "Bimbingan Praktikum Algoritma, Pemrograman & Struktur Data",
    summary:
      "Membimbing lebih dari 80 mahasiswa dalam memahami abstraksi struktur data kompleks (Linked List, Trees, Graphs, Sorting), review kode mingguan, dan pengujian kebenaran logika algoritma.",
    deliverables: [
      "Mengevaluasi ribuan baris kode mahasiswa dengan standar efisiensi memori (Big-O notation).",
      "Merancang materi modul praktikum interaktif dan studi kasus pemecahan masalah algoritma.",
      "Membantu mahasiswa yang mengalami kendala debugging logika pemrograman mendalam.",
    ],
    telemetryMetric: "80+ Mahasiswa Dibimbing // Zero-Defect Code",
    accent: "#FFD700",
  },
  {
    id: "pendidikan-formal",
    period: "2022 — Sekarang (Tingkat Akhir)",
    role: "Undergraduate Software Engineering",
    organization: "Telkom University Surabaya",
    type: "Undergraduate",
    headline: "Fokus Rekayasa Perangkat Lunak, Sistem Terdistribusi & IoT",
    summary:
      "Mendalami fondasi rekayasa perangkat lunak modern: Object-Oriented Design, Distributed Architecture, Basis Data Relasional & NoSQL, Metodologi Agile/Scrum, dan Keamanan Siber.",
    deliverables: [
      "Meraih pemahaman komprehensif pada perancangan arsitektur microservices dan cloud native.",
      "Aktif dalam berbagai proyek kolaborasi rekayasa sistem lintas platform.",
    ],
    telemetryMetric: "IPK Konsisten Tinggi // Rekayasa Sistem",
    accent: "#6CABDD",
  },
];

export interface StadiumState {
  // Modes & Zones
  viewMode: ViewMode;
  activeZone: StadiumZone;
  previousZone: StadiumZone;

  // Player & Ball
  playerCoordinates: [number, number, number]; // [x, y, z]
  playerHeading: number; // in radians
  ballCoordinates: [number, number, number];
  playerTarget: [number, number, number] | null;
  ballPass: BallPassState;

  // Modals & Overlays
  selectedLocker: LockerSkill | null;
  selectedTrophy: TrophyProject | null;
  selectedMilestone: TunnelMilestone | null;
  isJumbotronActive: boolean;
  activeHoveredProject: TrophyProject | null;

  // Sound & Telemetry
  audioEnabled: boolean;
  fps: number;
  activeVisitors: number;
  weatherCondition: { temp: string; status: string; city: string };

  // Onboarding
  hasSeenOnboarding: boolean;

  // Actions
  setViewMode: (mode: ViewMode) => void;
  toggleViewMode: () => void;
  setActiveZone: (zone: StadiumZone) => void;
  setPlayerCoordinates: (coords: [number, number, number]) => void;
  setPlayerHeading: (heading: number) => void;
  setPlayerTarget: (target: [number, number, number] | null) => void;
  setBallCoordinates: (coords: [number, number, number]) => void;
  setActiveHoveredProject: (project: TrophyProject | null) => void;

  // Curve Pass Trigger
  triggerCurvePass: (
    target: [number, number, number],
    targetType: BallPassState["targetType"],
    targetId: string | null
  ) => void;
  updateBallPassProgress: (progress: number) => void;
  finishBallPass: () => void;

  // Modals
  openLocker: (lockerId: LockerSkill["id"]) => void;
  closeLocker: () => void;
  openTrophy: (trophyId: string) => void;
  closeTrophy: () => void;
  openMilestone: (milestoneId: string) => void;
  closeMilestone: () => void;
  openJumbotron: () => void;
  closeJumbotron: () => void;
  closeAllModals: () => void;

  // Audio & Telemetry
  setAudioEnabled: (enabled: boolean) => void;
  toggleAudio: () => void;
  setFps: (fps: number) => void;
  setActiveVisitors: (count: number) => void;
  setWeather: (weather: { temp: string; status: string; city: string }) => void;
  dismissOnboarding: () => void;
}

export const useStadiumStore = create<StadiumState>((set, get) => ({
  viewMode: "3d",
  activeZone: "pitch",
  previousZone: "pitch",

  // Initial Player position at the pitch center
  playerCoordinates: [18, 0, 0],
  playerHeading: -Math.PI / 2,
  ballCoordinates: [18.8, 0.25, 0],
  playerTarget: null,

  ballPass: {
    isPassing: false,
    startX: 18.8,
    startY: 0.25,
    startZ: 0,
    targetX: 0,
    targetY: 0,
    targetZ: 0,
    curveHeight: 3.5,
    progress: 0,
    targetType: null,
    targetId: null,
  },

  selectedLocker: null,
  selectedTrophy: null,
  selectedMilestone: null,
  isJumbotronActive: false,
  activeHoveredProject: STADIUM_TROPHIES[1], // Smart Kandang as default focus

  audioEnabled: false,
  fps: 60,
  activeVisitors: 17,
  weatherCondition: { temp: "29°C", status: "Fair Skies", city: "Etihad Stadium, Surabaya" },

  hasSeenOnboarding: false,

  setActiveHoveredProject: (project) => set({ activeHoveredProject: project }),
  setPlayerHeading: (heading) => set({ playerHeading: heading }),

  setViewMode: (mode) => set({ viewMode: mode }),
  toggleViewMode: () =>
    set((state) => ({ viewMode: state.viewMode === "3d" ? "tactical-2d" : "3d" })),

  setActiveZone: (zone) =>
    set((state) => ({
      previousZone: state.activeZone,
      activeZone: zone,
    })),

  setPlayerCoordinates: (coords) =>
    set((state) => ({
      playerCoordinates: coords,
      // If ball is not in flight, keep it near player's feet
      ballCoordinates: state.ballPass.isPassing
        ? state.ballCoordinates
        : [coords[0] + 0.6, 0.25, coords[2]],
    })),

  setPlayerTarget: (target) => set({ playerTarget: target }),
  setBallCoordinates: (coords) => set({ ballCoordinates: coords }),

  triggerCurvePass: (target, targetType, targetId) => {
    const { playerCoordinates } = get();
    set({
      ballPass: {
        isPassing: true,
        startX: playerCoordinates[0] + 0.6,
        startY: 0.25,
        startZ: playerCoordinates[2],
        targetX: target[0],
        targetY: target[1],
        targetZ: target[2],
        curveHeight: Math.max(3.0, Math.hypot(target[0] - playerCoordinates[0], target[2] - playerCoordinates[2]) * 0.18),
        progress: 0,
        targetType,
        targetId,
      },
    });
  },

  updateBallPassProgress: (progress) =>
    set((state) => {
      const p = Math.min(Math.max(progress, 0), 1);
      const bp = state.ballPass;
      // Quadratic Bezier interpolation in 3D:
      // B(t) = (1-t)^2 * P0 + 2*(1-t)*t * P1 + t^2 * P2
      const t = p;
      const oneMinusT = 1 - t;
      const midX = (bp.startX + bp.targetX) / 2;
      const midY = Math.max(bp.startY, bp.targetY) + bp.curveHeight;
      const midZ = (bp.startZ + bp.targetZ) / 2;

      const currentX =
        oneMinusT * oneMinusT * bp.startX + 2 * oneMinusT * t * midX + t * t * bp.targetX;
      const currentY =
        oneMinusT * oneMinusT * bp.startY + 2 * oneMinusT * t * midY + t * t * bp.targetY;
      const currentZ =
        oneMinusT * oneMinusT * bp.startZ + 2 * oneMinusT * t * midZ + t * t * bp.targetZ;

      return {
        ballCoordinates: [currentX, currentY, currentZ],
        ballPass: { ...bp, progress: p },
      };
    }),

  finishBallPass: () => {
    const { ballPass, playerCoordinates } = get();
    const { targetType, targetId, targetX, targetY, targetZ } = ballPass;

    // Reset ball pass status and open corresponding modal
    set({
      ballPass: {
        isPassing: false,
        startX: targetX,
        startY: targetY,
        startZ: targetZ,
        targetX: playerCoordinates[0] + 0.6,
        targetY: 0.25,
        targetZ: playerCoordinates[2],
        curveHeight: 0,
        progress: 1,
        targetType: null,
        targetId: null,
      },
      // Keep ball at target briefly or near player
      ballCoordinates: [playerCoordinates[0] + 0.6, 0.25, playerCoordinates[2]],
    });

    if (targetType === "locker" && targetId) {
      const locker = STADIUM_LOCKERS.find((l) => l.id === targetId);
      if (locker) set({ selectedLocker: locker });
    } else if (targetType === "trophy" && targetId) {
      const trophy = STADIUM_TROPHIES.find((t) => t.id === targetId);
      if (trophy) set({ selectedTrophy: trophy });
    } else if (targetType === "milestone" && targetId) {
      const milestone = STADIUM_MILESTONES.find((m) => m.id === targetId);
      if (milestone) set({ selectedMilestone: milestone });
    } else if (targetType === "jumbotron") {
      set({ isJumbotronActive: true });
    }
  },

  openLocker: (lockerId) => {
    const locker = STADIUM_LOCKERS.find((l) => l.id === lockerId);
    if (locker) set({ selectedLocker: locker });
  },
  closeLocker: () => set({ selectedLocker: null }),

  openTrophy: (trophyId) => {
    const trophy = STADIUM_TROPHIES.find((t) => t.id === trophyId);
    if (trophy) set({ selectedTrophy: trophy });
  },
  closeTrophy: () => set({ selectedTrophy: null }),

  openMilestone: (milestoneId) => {
    const milestone = STADIUM_MILESTONES.find((m) => m.id === milestoneId);
    if (milestone) set({ selectedMilestone: milestone });
  },
  closeMilestone: () => set({ selectedMilestone: null }),

  openJumbotron: () => set({ isJumbotronActive: true }),
  closeJumbotron: () => set({ isJumbotronActive: false }),

  closeAllModals: () =>
    set({
      selectedLocker: null,
      selectedTrophy: null,
      selectedMilestone: null,
      isJumbotronActive: false,
    }),

  setAudioEnabled: (enabled) => set({ audioEnabled: enabled }),
  toggleAudio: () => set((state) => ({ audioEnabled: !state.audioEnabled })),
  setFps: (fps) => set({ fps }),
  setActiveVisitors: (count) => set({ activeVisitors: count }),
  setWeather: (weather) => set({ weatherCondition: weather }),
  dismissOnboarding: () => set({ hasSeenOnboarding: true }),
}));
