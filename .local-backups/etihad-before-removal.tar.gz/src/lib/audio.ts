// Web Audio API Procedural Sound Engine for Etihad Stadium
let audioCtx: AudioContext | null = null;
let crowdGainNode: GainNode | null = null;
let crowdSourceNode: AudioBufferSourceNode | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioCtx) {
      audioCtx = new AudioCtx();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Play authentic low-frequency soccer ball kick punch
 */
export function playKickSound(enabled = true) {
  if (!enabled) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;

  // Leather ball thump (sine sweep 180Hz -> 38Hz)
  const osc = ctx.createOscillator();
  const oscGain = ctx.createGain();

  osc.type = "sine";
  osc.frequency.setValueAtTime(180, now);
  osc.frequency.exponentialRampToValueAtTime(38, now + 0.12);

  oscGain.gain.setValueAtTime(0.7, now);
  oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

  osc.connect(oscGain);
  oscGain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.16);

  // Noise click for leather ball texture
  const bufferSize = ctx.sampleRate * 0.05;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.01));
  }

  const noise = ctx.createBufferSource();
  noise.buffer = buffer;

  const noiseFilter = ctx.createBiquadFilter();
  noiseFilter.type = "lowpass";
  noiseFilter.frequency.setValueAtTime(1200, now);

  const noiseGain = ctx.createGain();
  noiseGain.gain.setValueAtTime(0.35, now);
  noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

  noise.connect(noiseFilter);
  noiseFilter.connect(noiseGain);
  noiseGain.connect(ctx.destination);

  noise.start(now);
}

/**
 * Play authentic two-tone referee whistle blast
 */
export function playWhistleSound(enabled = true) {
  if (!enabled) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const duration = 0.28;

  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();
  const gain = ctx.createGain();

  osc1.type = "sine";
  osc2.type = "sine";

  // Harmonic trill frequencies
  osc1.frequency.setValueAtTime(2600, now);
  osc2.frequency.setValueAtTime(2880, now);

  // LFO vibrato
  const lfo = ctx.createOscillator();
  lfo.frequency.setValueAtTime(32, now);
  const lfoGain = ctx.createGain();
  lfoGain.gain.setValueAtTime(45, now);
  lfo.connect(osc1.frequency);
  lfo.connect(osc2.frequency);
  lfo.start(now);
  lfo.stop(now + duration);

  gain.gain.setValueAtTime(0.01, now);
  gain.gain.linearRampToValueAtTime(0.18, now + 0.03);
  gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

  osc1.connect(gain);
  osc2.connect(gain);
  gain.connect(ctx.destination);

  osc1.start(now);
  osc2.start(now);
  osc1.stop(now + duration);
  osc2.stop(now + duration);
}

/**
 * Play celebratory goal explosion & crowd roar
 */
export function playGoalCheer(enabled = true) {
  if (!enabled) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const duration = 1.4;

  // Stadium horn synth
  [220, 277.18, 329.63, 440].forEach((freq) => {
    const horn = ctx.createOscillator();
    const hornGain = ctx.createGain();
    horn.type = "sawtooth";
    horn.frequency.setValueAtTime(freq, now);

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(1400, now);

    hornGain.gain.setValueAtTime(0.08, now);
    hornGain.gain.exponentialRampToValueAtTime(0.001, now + 0.9);

    horn.connect(filter);
    filter.connect(hornGain);
    hornGain.connect(ctx.destination);

    horn.start(now);
    horn.stop(now + 1.0);
  });

  // Massive crowd noise surge
  const bufferSize = ctx.sampleRate * duration;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let lastOut = 0.0;
  for (let i = 0; i < bufferSize; i++) {
    const white = Math.random() * 2 - 1;
    data[i] = (lastOut + 0.02 * white) / 1.02;
    lastOut = data[i];
    data[i] *= 3.5;
  }

  const noise = ctx.createBufferSource();
  noise.buffer = buffer;

  const crowdFilter = ctx.createBiquadFilter();
  crowdFilter.type = "bandpass";
  crowdFilter.frequency.setValueAtTime(650, now);
  crowdFilter.Q.setValueAtTime(0.8, now);

  const cheerGain = ctx.createGain();
  cheerGain.gain.setValueAtTime(0.05, now);
  cheerGain.gain.linearRampToValueAtTime(0.28, now + 0.3);
  cheerGain.gain.exponentialRampToValueAtTime(0.001, now + duration);

  noise.connect(crowdFilter);
  crowdFilter.connect(cheerGain);
  cheerGain.connect(ctx.destination);

  noise.start(now);
}

/**
 * Manage ambient stadium murmur loop with volume modulation
 */
export function updateStadiumAmbiance(enabled: boolean, zoneVolume = 0.12) {
  const ctx = getAudioContext();
  if (!ctx) return;

  if (!enabled) {
    if (crowdGainNode) {
      crowdGainNode.gain.setTargetAtTime(0, ctx.currentTime, 0.1);
    }
    return;
  }

  if (!crowdSourceNode) {
    const bufferDuration = 3.0;
    const bufferSize = ctx.sampleRate * bufferDuration;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99 * b0 + white * 0.05;
      b1 = 0.95 * b1 + white * 0.03;
      b2 = 0.90 * b2 + white * 0.02;
      data[i] = (b0 + b1 + b2) * 0.2;
    }

    crowdSourceNode = ctx.createBufferSource();
    crowdSourceNode.buffer = buffer;
    crowdSourceNode.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(450, ctx.currentTime);

    crowdGainNode = ctx.createGain();
    crowdGainNode.gain.setValueAtTime(0.01, ctx.currentTime);

    crowdSourceNode.connect(filter);
    filter.connect(crowdGainNode);
    crowdGainNode.connect(ctx.destination);

    crowdSourceNode.start(0);
  }

  if (crowdGainNode) {
    crowdGainNode.gain.setTargetAtTime(Math.min(zoneVolume, 0.25), ctx.currentTime, 0.2);
  }
}
