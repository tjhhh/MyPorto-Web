import React from "react";
import type { Metadata } from "next";
import { EtihadCanvas } from "@/components/canvas/EtihadCanvas";
import { TopBar } from "@/components/hud/TopBar";
import { RadarMinimap } from "@/components/hud/RadarMinimap";
import { TelemetryScoreboard } from "@/components/hud/TelemetryScoreboard";
import { VirtualJoystick } from "@/components/hud/VirtualJoystick";
import { OnboardingTooltip } from "@/components/hud/OnboardingTooltip";
import { FUTCardModal } from "@/components/hud/FUTCardModal";
import { VARReviewModal } from "@/components/hud/VARReviewModal";
import { MilestoneModal } from "@/components/hud/MilestoneModal";
import { JumbotronContactModal } from "@/components/hud/JumbotronContactModal";
import { TacticalBoardView } from "@/components/tactical-2d/TacticalBoardView";

export const metadata: Metadata = {
  title: "Muhammad Fauzan #17 — Etihad 3D Diorama & Tactical Portfolio",
  description:
    "Web portofolio interaktif 3D Cutaway Diorama bertema Etihad Stadium. Eksplorasi PlayStyles+ Tiki-Taka, Ruang Kontrol VAR, Lorong Kaca, dan Jumbotron Kick-Off.",
  openGraph: {
    title: "Muhammad Fauzan #17 — Etihad 3D Diorama Portfolio",
    description: "3D Cartoon Tactical Diorama Portfolio & Pep's Tactical 2D View",
    type: "website",
  },
};

export default function Home() {
  return (
    <div className="relative w-full min-h-screen bg-[#070c14] text-white overflow-hidden">
      {/* 1. HUD: Navigation TopBar */}
      <TopBar />

      {/* 2. Main 3D Cutaway Diorama WebGL Canvas */}
      <main className="relative w-full h-screen overflow-hidden">
        <EtihadCanvas />

        {/* 3. Tactical 2D Board Mode (Always in DOM for 100% SEO & Screen Readers) */}
        <TacticalBoardView />
      </main>

      {/* 4. HUD Overlays & Instruments */}
      <RadarMinimap />
      <TelemetryScoreboard />
      <VirtualJoystick />
      <OnboardingTooltip />

      {/* 5. Interactive Modals (Triggered via Object Clicks) */}
      <FUTCardModal />
      <VARReviewModal />
      <MilestoneModal />
      <JumbotronContactModal />
    </div>
  );
}
