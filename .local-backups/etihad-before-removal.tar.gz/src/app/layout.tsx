import type { Metadata, Viewport } from "next";
import { Montserrat, JetBrains_Mono } from "next/font/google";
import { AmbientSpotlight } from "@/app/_components/motion";
import "./globals.css";

const montserrat = Montserrat({
  variable: "--font-sans",
  subsets: ["latin"],
  display: "swap",
  weight: ["200", "300", "400", "500", "600", "700", "800", "900"],
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
  display: "swap",
  weight: ["300", "400", "500", "700"],
});

export const viewport: Viewport = {
  themeColor: "#070C14",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  title: "Muhammad Fauzan #17 — Etihad 3D Diorama & Tactical Portfolio",
  description:
    "Web portofolio interaktif 3D Cutaway Diorama bertema Etihad Stadium. Eksplorasi PlayStyles+ Tiki-Taka, Ruang Kontrol VAR, Lorong Kaca, dan Jumbotron Kick-Off.",
  authors: [{ name: "Muhammad Fauzan" }],
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
      { url: "/favicon.svg", type: "image/svg+xml" },
    ],
    shortcut: "/icon.svg",
    apple: "/icon.svg",
  },
  openGraph: {
    title: "Muhammad Fauzan #17 — Etihad 3D Diorama Portfolio",
    description: "3D Cartoon Tactical Diorama Portfolio & Pep's Tactical 2D View",
    type: "website",
    locale: "en_US",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${montserrat.variable} ${jetbrainsMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-background text-foreground selection:bg-maroon selection:text-milky-white relative">
        <AmbientSpotlight />
        {children}
      </body>
    </html>
  );
}
